#! /bin/bash



#########################################################################################################
# Options des arguments :                                                                               #
# -i ou --in      => indique la feuille de calcul initiale,si absente alors l'entrée est le clavier.    #
# -o ou --out     => indique la feuille de résultat, si elle est absente alors la sorte sera l'écran.   #
# -c ou --scin    => indique le séparateur de colone de la feuille initiale, par defaut : \t.           #
# -l ou --slin    => indique le séparateur de ligne de la feuille de calcule initiale, par défaut : \r  #
# -u ou --scout   => indique le séparateur de colonne du résultat, par défaut égal à scin.              #
# -t ou --slout   => indique le séparateur de ligne du résultat, par défaut égal à slin.                #
# -v ou --inverse => inverse les lignes et les colonnes.                                                #
#########################################################################################################


##-----  Declaration des Variables Globales pour l'ensemble des fonctions du projets ----- ###
fic_ini=""  # Cette variable contiendra le fichier initial où se trouvera la feuille de calcul.
fic_res=""  #Cette variable contiendra le fichier résultat.
sep_col_ini="" # cette variable contiendra le séparateur colonne du fichier initial
sep_lig_ini="" # cette variable contiendra le séparateur ligne du fichier initial
sep_col_res="" # cette variable contiendra le séparateur colonne du fichier de sortie.
sep_ilg_res="" # cette variable contiendra le séparateur ligne du fichier de sortie.
var_inver=""   # cette variable permettra de dire si oui ou non on dois inverser les ligne et colonee
res=0 # cette variable contiendra les résultats de chaque opération.


####----- On teste si les option entrées sont les bonnes et que les fichiers existent réelement.-----####
function VerifiOptions ()
{
 
while [ $# -ne 0 ];do
if [ $1 != "-i" ] && [ $1 != "-o" ] && [ $1 != "-l" ] && 
   [ $1 != "-c" ] && [ $1 != "-s" ] && [ $1 != "-r" ] && 
   [ $1 != "-t" ] && [ $1 != "-in" ] && [ $1 != "-out" ] && 
   [ $1 != "-scin" ] && [ $1 != "-slin" ] && [ $1 != "-scout" ] &&  
   [ $1 != "-slout" ] && [ $1 != "-inverse" ] && [ ! -f $1 ]&& [ $1 != ":" ] && 
   [ $1 != "\n" ] && [ $1 != ";" ]&& [ $1 != "|" ]&& [ $1 != "-" ];then
echo "$0 : no such argument or file $1, please see <man tableur> for more informations"
exit 0 
fi
shift
done  

}


#--- Test si le fichier passer en argument existe ---#
function TestFichier ()
{
  
 if [ ! -f $1 ] && [ ! -f $2 ] ;then

     echo "$1 et $2 have to be file"
     echo "$0: see [-i | in] or [-o | out] in the <man tableur>"
     exit 0

 fi
   
}


#--- On prend les différents arguments passé en paramètre ---#

function RechercheArgument ()
{


        while [ "$#" -ne 0 ] ; do
        
		      case "$1" in

		            "-in" | "-i")  shift 
		                           fic_ini="$1";;
		                           
			       "-out" | "-o" ) shift 
			                       fic_res="$1";;
			                  
			      "-scin" | "-c" )shift
			                     sep_col_ini="$1";;
			                  
			      "-slin" | "-l" )shift
			                     sep_lig_ini="$1";;
			                  
			     "-scout" | "-s" )shift
			                     sep_lig_res="$1";;
			                  
			     "-slout" | "-t" )shift
			                     sep_col_res="$1";;
			                  
		         "-inverse" | "-r" )shift 
		                              var_inver=1;;

		     esac
            
          shift
        
        done
   
   
   

}


#--- Ici on recupère la valeur d'une cellule: cette fonction prend deux paramètres l et c ---#
function Valeur ()
{

local saveIFS 
# Je compte le nombre de ligne de notre fichiier
Nbligne=`wc -l "$fic_ini" | cut -d " " -f 1 `
saveIFS=$IFS # 

valcol=$2
valigne=$1

# Je change l'IFS avec le séparateur colonne initial.
ChangerIFS "$sep_lig_ini" 

# Je change les valeurs de variables de positions.
set -- `cat $fic_ini`

local i=0

while [ $# -ne 0 ]; do


   if  [  $i -eq  $valigne  ];then

	  valligne2=$1
	  valcel=`echo $valligne2 | cut -d : -f $((valcol+1))` 


   fi


  i=`expr "$i" + 1`
shift
done

IFS=$saveIFS

}

#--- Cette fonction nous permet de recupérer le numero ligne et colone de nos cellules. ---#
function LigneColonne ()
{

	
		l=`echo $1 | cut -d l -f 2 | cut -d c -f 1`
		c=`echo $1 | cut -d c -f 2`
	
}

#--- Cette focntion teste si la valeur qui lui est passée en argument est un réel ---#

function estReel ()
{
local saveIFS
val="true"
test $# -ne 1 && echo "Usage $0 nbre" && echo "Verifie que nbre est un réel" 
var="$1"
ssaveIFS="$IFS"
IFS=.
set -- $1

test $# -gt 2 && echo "Syntaxe de <$var> ne correspond pas à un réel" 
	expr "$1" + "$1" >/dev/null 2>&1
	test $? -eq 2 && val="false" 
	shift
	if test $# -eq 2 
	then 
		expr "$2" + "$2" >/dev/null 2>&1
		test $2 -eq 2 && echo "test" 
		test $2 -lt 0 0 && echo "..." 
	fi


IFS="$saveIFS"
}


#--- Cette fonction teste si la valeur qui lui est passée en argument est un entier ----#
function estEntier ()
{

estReel $1
saveIFS=$IFS
IFS=.
set -- $1
	if [ $val == "true" ]; then
		if [ $# -eq 2 ]; then
   			val="false"
		else val="true"
		fi
	fi
}

#Cette fonction nous permettra de changer l'IFS de nos arguments
#elle recevra en paramètre les arguments lignes et colonnes entrées par l'utilisateur.
#IFS contient par défauts: espace(" "),tabulation(\t,\v),retour chariot(\r)
function ChangerIFS ()
{
    if [  $# -ne 0 ];then
              
           case "$1" in
              "|") IFS="|";;
              "&") IFS="&";;
              ";") IFS=";";;
              ",") IFS=",";;
              "-") IFS="-";;
             "\n") IFS="
";;
              ":") IFS=":";;
           
         esac
    fi


}
#Je recupère les différents arguments passés en ligne de commande.

VerifiOptions $@

 if [  $# -ne 0  ] ; then

        RechercheArgument "$@"

 fi

#---------------------------------------------------------------------------#
#remplace le contenu de la cellule par le résultat de la commade val
#Synoptique: shell(val) : val dois être une commande.
#---------------------------------------------------------------------------#
function shell ()
 {
   local saveIFS
   local oper=""

   
   
   saveIFS=$IFS
   IFS=" "
   set -- $1
   
   while [ $# -ne 0 ] ; do
   
        oper="$oper $1" 
       
    shift
    
   done
  
   
    res=`$oper`
    IFS=$saveIFS
 }

#--------------------------------------------------------------------------#
#Synoptique: Addition(c1l1,c2L3) ou +(c1l1,c2L3)
#effectue la somme des cellules c1l1 et c2l3 et les valeurs des paramètres
#peuvent être encore une opération.
#--------------------------------------------------------------------------#
function Addition ()
{

local l1
local c1
local l2
local c2
local x
local y


    LigneColonne $1
    l1=$l
    c1=$c
    LigneColonne $2
    l2=$l
    c2=$c
    
    Valeur $l1 $c1
    x=$valcel

    Valeur $l2 $c2
    y=$valcel
   
     res=`echo "$x + $y" | bc -l`
  
}

#------------------------------------------------------------------------------#
#Synoptique:subtitute(val1,val2,val3)
#rempalce dans la chaine de caractère val1, la chaine de carctère val2 par val3
#------------------------------------------------------------------------------#
function Substitute ()
{
   

    x=$1
    y=$2
    z=$3

 if [ ! -z $x ] && [ ! -z $y ] && [ ! -z $z ] ; then
 
        res=`${$x//$y/$z}`

 else
    
        echo "$x ou $y ou $z sont vides."
        exit 0
 
 fi


}

#---------------------------------------------------------------------#
#Synoptique: somme(cel1,cel2)
#effectue la somme des cellules appartenant à l'interval cel1 à cel2.
#les paramètres peuvent être encore une opération.
#---------------------------------------------------------------------#
function Somme ()
{

concat2 $1 $2
res2=$res
saveIFS=$IFS
IFS=" "
set -- $res2
res=0
while [ $# -ne 0 ]; do

res=`expr $res + $1 | bc -ls`

shift

done


IFS=$saveIFS
 
}

#--------------------------------------------------#
#Synoptique: produit(cel1,cel2) ou *(cel1,cel2)
#effectue le produit des cellules cel1 et cel2.
#les paramètres peuvent être encore une opération.
#--------------------------------------------------#
function Produit ()
{

local l1
local c1
local l2
local c2
local x
local y
local r1
local r2

    estReel $1
    r1=$val
    estReel $2
    r2=$val

    if [ $r1 == "false"	]; then
    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel
    else 
    x=$1
    fi
    if [ $r2 == "false"	]; then
    LigneColonne $2
    l2=$l
    c2=$c
    Valeur $l2 $c2
    y=$valcel
    else
    y=$2
    fi 

    res=`echo "$x * $y" | bc -l`
}

#-------------------------------------------------------#
#Synoptique: soustraction(cel1,cel2) ou -(cel1,cel2)
#effectue la ssoustraction des cellules  cel1 et cel2.
#les paramètres peuvent être encore une opération.
#-------------------------------------------------------#

function Soustraction ()
{
local l1
local c1
local l2
local c2
local x
local y
local r1
local r2

    estReel $1
    r1=$val
    estReel $2
    r2=$val
 	
    if [ $r1 == "false"	]; then
    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel
    else 
    x=$1
    fi
    if [ $r2 == "false"	]; then
    LigneColonne $2
    l2=$l
    c2=$c
    Valeur $l2 $c2
    y=$valcel
    else
    y=$2
    fi 

   res=`echo "$x - $y" | bc -l`
}

#---------------------------------------------------#
#Synoptique: division(cel1,cel2) ou /(cel1,cel2)
#effectue la somme des cellules cel1 et cel2.
#les paramètres peuvent être encore une opération.
#--------------------------------------------------#

function Division ()
{

local l1
local c1
local l2
local c2
local x
local y
local r1
local r2

    estReel $1
    r1=$val
    estReel $2
    r2=$val

    if [ $r1 == "false"	]; then
    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel
    else 
    x=$1
    fi
    if [ $r2 == "false"	]; then
    LigneColonne $2
    l2=$l
    c2=$c
    Valeur $l2 $c2
    y=$valcel
    else
    y=$2
    fi

    res=`echo "$x / $y" | bc -l`
}

#--------------------------------------------------------------------#
#Synoptique: size(val)
#recupère la taille du fichier identifié par val
# val : dois être un fichier et exister dans le repertoire en cours.
#--------------------------------------------------------------------#

function Size ()
{
 
  
  
  if [ -f  $1 ];then
  
      res=`ls -s $1 | cut -d " " -f 1`
  
  else
  
    echo "$1 n 'est pas un fichier"
    exit 0
  
  fi
  
    
}

#--------------------------------------------------------------------#
#Synoptique: length(val)
#fournit la longeur de la chaine de carctère val
# val : dois être une chaine de caratère.
#--------------------------------------------------------------------#

function Length ()
{
local val
val=$1
  if [ ! -z $1 ] ; then

       res=`#$val`
  
  else
  
       echo "$1 est vide"
       exit 0

  fi


}

#------------------------------------------------------#
#Synoptique: puissance(val1,val2) ou ^(val1,val2)
#élève val1 à la puissance de val2.
#val1 et val2 : doivent être des réels ou des entiers.
#------------------------------------------------------#
function Puissance ()
{

local l1
local c1
local l2
local c2
local x
local y
local r1
local r2

    estReel $1
    r1=$val
    estReel $2
    r2=$val

    if [ $r1 == "false"	]; then
    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel
    else 
    x=$1
    fi
    if [ $r2 == "false"	]; then
    LigneColonne $2
    l2=$l
    c2=$c
    Valeur $l2 $c2
    y=$valcel
    else
    y=$2
    fi
 
     res=`"$x^$y" | bc -l`
     
}

#----------------------------------------------#
#Synoptique: sqrt(val)
#calcul la racine carré de val
#val : dois être un nombre réel et non vide.
#----------------------------------------------#
function Sqrt ()
{

local l1
local c1
local x
local r1

   estReel $1
   r1=$val

   if [ $r1 == "false"	]; then
    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel
    else 
    x=$1
    fi

    res=`expr "sqrt($x)" | bc -l`
}


#----------------------------------------------#
#Synoptique: ln(val)
#calcul le logarithme népérien de val
#val : dois être un nombre réel et non vide.
#----------------------------------------------#
function Logarithme ()
{
local l1
local c1
local x
local r1

   estReel $1
   r1=$val

   if [ $r1 == "false"	]; then
    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel
    else 
    x=$1
    fi
    res=`expr "l($x)" | bc -l`
   
}

#----------------------------------------------#
#Synoptique: e(val)
#calcul l'exponnentielle de val
#val : dois être un nombre réel et non vide.
#----------------------------------------------#

function Exponentielle ()
{
local l1
local c1
local x
local r1

   estReel $1
   r1=$val

   if [  $r1 == "false"	]; then
   
	    LigneColonne $1
	    l1=$l
	    c1=$c
	    Valeur $l1 $c1
	    x=$valcel
  else 
  
            x=$1
  
  fi

   res=`expr "e($x)" | bc -l`
  
}

#----------------------------------------------#
#Synoptique: lines(val)
#calcul le nombre de ligne d'un fichier
#val : dois être un fichier et non vide.
#----------------------------------------------#
function Lines ()
{
   if [ ! -z $1 ];then
    
      res=`wc -l $1 | cut -d " " -f 1`
      
  else
     echo "$1 est vide "
     exit 0

   fi


}

#--------------------------------------------------------------------#
#Synoptique: moyenne(cel1,cel2)
#calcul la moyenne des cellules appartenant à l'intervalle cel1 à cel2
#les valeurs doivent être sur le même ligne.
#--------------------------------------------------------------------#

function Moyenne ()
{

local saveIFS
concat2 $1 $2
cptmoy=$#

res2=$res
saveIFS=$IFS
IFS=" "
set -- $res2
res=0
while [ $# -ne 0 ]; do

res=`expr $res + $1`

shift

done

Division $res $cptmoy

IFS=$saveIFS

}

#--------------------------------------------------------------------#
#Synoptique: variance(cel1,cel2)
#calcul la variance des cellules appartenant à l'intervalle cel1 à cel2
#les valeurs doivent être sur le même ligne.
#--------------------------------------------------------------------#

function Variance ()
{
moyenne $1 $2
moy=$res
cpt=$cpt
local val2

concat2 $1 $2
cpt=$#
res2=$res
saveIFS=$IFS
IFS=" "
set -- $res2
res=0
while [ $# -ne 0 ]; do

	val2=`expr $1 - $moy | bc -l`
	val2=`expr $val2 / $cpt | bc -l`
	res=`expr $res + $val2`

shift

done

IFS=$saveIFS
}

#--------------------------------------------------------------------#
#Synoptique: ecarttype(cel1,cel2)
#calcul l'écarttype des cellules appartenant à l'intervalle cel1 à cel2
#les valeurs doivent être sur le même ligne.
#--------------------------------------------------------------------#
function Ecarttype ()
{
	Variance $1 $2
	var=$res
echo "aiiiiiiiiiiiiiiiieeeeeeeee" $var
	res=`expr "sqrt($var)" | bc -l`
}

#------------------------------------------------------------------------------#
#Synoptique: min(cel1,cel2)
#calcul la plus petite valeur des cellules appartenant à l'intervalle cel1 à cel2
#les valeurs doivent être sur le même ligne.
#------------------------------------------------------------------------------#

function Min ()
{

concat2 $1 $2
res2=$res

local saveIFS=$IFS
IFS=" "
set -- $res2
res=1000000
while [ $# -ne 0 ]; do

	if [ $1 -lt $res ]; then
		res=$1
	fi

shift

done



IFS=$saveIFS
 
}

#------------------------------------------------------------------------------#
#Synoptique: max(cel1,cel2)
#calcul la plus grande valeur des cellules appartenant à l'intervalle cel1 à cel2
#les valeurs doivent être sur le même ligne.
#------------------------------------------------------------------------------#
function Max ()
{

local saveIFS
concat2 $1 $2

res2=$res

saveIFS=$IFS
IFS=" "
set -- $res2
res=0
while [ $# -ne 0 ]; do

	if [ $1 -gt $res ]; then
		res=$1
	fi
shift

done



IFS=$saveIFS
 
}

#------------------------------------------------------------------------------#
#Synoptique: mediane(cel1,cel2)
#calcul de la mediane des cellules appartenant à l'intervalle cel1 à cel2
#les valeurs doivent être sur le même ligne.
#------------------------------------------------------------------------------#
function Mediane ()
{

local l1
local c1
local l2
local c2
local x
local y



    LigneColonne $1
    res=0
    l1=$l
    c1=$c
    LigneColonne $2
    l2=$l
    c2=$c
    local ligne=0
    local colonne=0

#ajout des éléments dans le fichier mediane.txt

    if [ $l1 -gt $l2 ]; then
        ligne=$l2
        if [ $c1 -gt $c2 ] ;then
            colonne=$c2
            while [ $colonne -le $c1 ]; do
                while [ $ligne -le $l1 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    echo $res >> mediane.txt
                    ligne=`expr "$ligne" + 1`
                done
                colonne=`expr "$colonne" + 1`
                ligne=$l2
            done
        elif [ $c2 -ge $c1 ] ;then
            colonne=$c1
            while [ $colonne -le $c2 ]; do
                while [ $ligne -le $l1 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    echo $res >> mediane.txt
                    ligne=`expr "$ligne" + 1`
                done
            colonne=`expr "$colonne" + 1`
            ligne=$l2
            done
        fi
    elif [ $l2 -ge $l1 ]; then
        ligne=$l1
        if [ $c1 -gt $c2 ] ;then
            colonne=$c2
            while [ $colonne -le $c1 ]; do
                while [ $ligne -le $l2 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    echo $res >> mediane.txt
                    ligne=`expr "$ligne" + 1`
                done
                colonne=`expr "$colonne" + 1`
            	ligne=$l1
            done
        elif [ $c2 -ge $c1 ] ;then
            colonne=$c1
            while [  $colonne -le  $c2  ]; do
                while [ $ligne -le  $l2 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    echo $res >> mediane.txt
                    ligne=`expr "$ligne" + 1`
                done
                colonne=`expr "$colonne" + 1`
                ligne=$l1
            done
        fi
    fi

Nbelt=`wc -L mediane.txt | cut -d " " -f 1`

#on trie les éléments et on les ajoute au fichier mediane2.txt
sort -g mediane.txt > mediane2.txt

mod=`expr $Nbelt % 2`
echo $mod


	if [ $mod -eq 1 ]; then
		taille=`expr $Nbelt / 2 + 1`
		echo $taille
	else 
		taille=`expr $Nbelt / 2`
		taille2=`expr $taille + 1`
		echo $taille
		echo $taille2
	fi

local cpt=1
local saveIFS=$IFS
IFS="
"
set -- mediane.txt

#recherche de la valeur mediane

while [ $# -ne 0 ]; do
 if [ $mod -eq 0 ]; then
 	if [ $cpt -eq $taille ]; then
		res1=$1
		res2=$2
 	fi
  res=`expr $res1 + $res2`
  res=`expr $res / 2`
 else if [ $cpt -eq $taille ]; then
		res=$1
      fi
 fi


cpt=`expr $cpt + 1`
shift
done

echo $res
}


#-----------------------------------------------------#
#Synoptique: display(cel1,cel2)
#permet de spécifier un ensemble de cellule à afficher
#-----------------------------------------------------#
function display ()
{
   concat2 $1 $2
   res=`echo $res`
}

#--------------------------------------------------------------------#
#Synoptique: concat(val1,val2)
#effectue la concatenation de deux chaines de caractère val1 et val2.
#les valeurs doivent être sur le même ligne.
#---------------------------------------------------------------------#
function Concat ()
{

x=$1
y=$2

echo "=======================yihhhhaaaaaaaaa==========" $1
 
     res=`echo "$x $y"`
}

#--------------------------------------------------------------------#
#Synoptique: concat(l1c1,l2c2)
#effectue la concaténation dans une chaine de caractères de tous les 
#élements présents dans l'intervalle l1c1 - l2c2
#---------------------------------------------------------------------#

function concat2 ()
{

local l1
local c1
local l2
local c2
local x
local y


    LigneColonne $1
    res=""
    l1=$l
    c1=$c
    LigneColonne $2
    l2=$l
    c2=$c
    local ligne=0
    local colonne=0

    if [ $l1 -gt $l2 ]; then
        ligne=$l2
        if [ $c1 -gt $c2 ] ;then
            colonne=$c2
            while [ $colonne -le $c1 ]; do
                while [ $ligne -le $l1 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    res="$res $val"
                    ligne=`expr "$ligne" + 1`
                done
                colonne=`expr "$colonne" + 1`
                ligne=$l2
            done
        elif [ $c2 -ge $c1 ] ;then
            colonne=$c1
            while [ $colonne -le $c2 ]; do
                while [ $ligne -le $l1 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    res="$res $val"
                    ligne=`expr "$ligne" + 1`
                done
            colonne=`expr "$colonne" + 1`
            ligne=$l2
            done
        fi
    elif [ $l2 -ge $l1 ]; then
        ligne=$l1
        if [ $c1 -gt $c2 ] ;then
            colonne=$c2
            while [ $colonne -le $c1 ]; do
                while [ $ligne -le $l2 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    res="$res $val"
                    ligne=`expr "$ligne" + 1`
                done
                colonne=`expr "$colonne" + 1`
            	ligne=$l1
            done
        elif [ $c2 -ge $c1 ] ;then
            colonne=$c1
            while [  $colonne -le  $c2  ]; do
                while [ $ligne -le  $l2 ]; do
                    Valeur $ligne $colonne
                    val=$valcel
                    res="$res $val"
                    ligne=`expr "$ligne" + 1`
                done
                colonne=`expr "$colonne" + 1`
                ligne=$l1
            done
        fi
    fi

}

#--------------------------------------------------------------------#
#Synoptique: inverse(nomfichier)
#Inverse ligne et colonne du fichier dans un autre fichier
#---------------------------------------------------------------------#

function inverse ()
{
local ligne=" "
local nbcol=0
local nbligne=0
local fic=""
local k=0
local j=0
local i=1
local e=0

if [ $# -eq 1  ]; then
fic=`cat $1`
nbligne=`wc -l "$1" | cut -d " " -f 1`
IFS="
"
set -- $fic
#====================================================================#
#===== Compte le nombre de colonne du fichier =======================#
#== et je prend la ligne qui à le nombre de colonne le plus grand ===#
#====================================================================#
while [  $nbligne -ge $i  ] ; do

if [ ! -z $1 ]; then
IFS=":"
set -- $1
nbcol1=$# 

fi

if [ $i -eq 1  ];then

nbcol=$nbcol1 

elif [ $nbcol -lt $nbcol1 ]; then

nbcol=$nbcol1   

fi

IFS="
"
set -- $fic 
shift $i
i=`expr $i + 1`
done

IFS=$saveIFS

#================================================================#
#===== Je fais l'inversion des lignes et des colonnes ===========#
#================================================================#
i=1
IFS="
"
set -- $fic
while [ $nbcol -ge $i  ] ; do

#echo "==i1==" $i
while [  $# -ne 0 ]; do

#echo $1
val=`echo $1 | cut -d ":" -f $i`
if [ ! -z  $val ];then 
e=`expr $e + 1`
if [ ! -z  $val ] && [ $e -eq 1 ];then

ligne="$ligne $val"

elif [ ! -z  $val ];then

ligne="$ligne : $val"

fi
fi
val=""


shift
done

echo $ligne >>tmp.txt
ligne=" "
e=0
FS="
"
set -- $fic 
i=`expr $i + 1`
done

fi

if [ ! -z $fic_ini ];then

echo tmp.txt > fic_ini   #rempli le fichier d'entrée.
else
echo tmp.txt             #affiche à l'écran

fi 


}

#-------------------------------------------------------#
#Synoptique: cos(val1)
#Calcule le cosinus de val1
#-------------------------------------------------------#
function cos ()
{
local l1
local c1
local x
local r1

echo "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" $1

    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel


res=`expr "c ($x)" | bc -l`
echo $res

}

#-------------------------------------------------------#
#Synoptique: sin(val1)
#Calcule le sinus de val1
#-------------------------------------------------------#
function sin ()
{
local l1
local c1
local x
local r1


    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel


res=`expr "s ($x)" | bc -l`
echo $res

}

#-------------------------------------------------------#
#Synoptique: arctan(val1)
#Calcule la tangente de val1
#-------------------------------------------------------#
function arctan ()
{
local l1
local c1
local x
local r1

 


    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel
    

res=`expr "a ($x)" | bc -l`
echo $res

}

#-------------------------------------------------------#
#Synoptique: NbreDecimal(val1)
#Calcule le nombre de décimales de val1
#-------------------------------------------------------#
function NbreDecimal ()
{
local l1
local c1
local x
local r1

  
    LigneColonne $1
    l1=$l
    c1=$c
    Valeur $l1 $c1
    x=$valcel


res=`echo "scale ($x)" | bc -l`
echo $res
}


#------------------------------------------------------------------------------#
#Synoptique:Operation [operation]
#permmet de recupérer l'opération passé en paramètre et de choisir la fonction
#corespondante afin de la réaliser et de renvoyer le résultat dans la variable 
#res.
#------------------------------------------------------------------------------#
cptdis=0

function Operation ()
{
local l1
local c1
local saveIFS



    
  saveIFS=$IFS
  oper=`echo $1 | cut -d = -f 2`
 
  #Je recupère le premier élément: si oper=[cel]
  val3=${oper:0:1}
  
  
  if [ $val3 = "[" ] ; then
  
	    #je recupère la cellule: cel : traitement pour [] cel = lacb
	    cel=`echo $oper | cut -d [  -f  2 | cut -d ] -f  1`
	    
	    #traitement pour récupérer la valeur de la cellule.
	    LigneColonne $cel
	    l1=$l
	    c1=$c
	    Valeur $l1 $c1
	    res=$valcel
	    
	    echo "res" $res
    
     
  else 
  
  IFS="(,)"
  set -- $oper

 if [ $1 == "display" ]; then
 cptdis=1
 fi

  case $1 in
  
	   e) Exponentielle $2;;
	   size)Size $2;;
	   length)Length $2;;
	   lines)Lines $2;;
	   shell)shell $2;;
	   min)Min $2 $3;;
	   ln)Logarithme $2 ;;
	    max)Max $2 $3;;
	    + | somme)Somme $2 $3;;
	     sqrt) Sqrt $2;;
	    / | div )Division $2 $3;;
	    - | sous)Soustraction $2 $3;;
	    moyenne)Moyenne $2 $3;;
	    display)display $2 $3;;
	    additon)Addition $2 $3;;
	    * | produit)Produit $2 $3;;
	    ^ | puiss | pow ) Puissance $2 $3;;
	    variance)Variance $2 $3;;
	    ecarttype)Ecarttype $2 $3;;
	    mediane)Mediane $2 $3;;
	    substitute)Substitute $2 $3 $4;;
	    concat)Concat $2 $3;;
            cos) cos $2;;
            sin) sin $2;;
            arctan) arctan $2;;
            NbreDecimal) NbreDecimal $2;;
	    ?)echo "Operation Inconnue";;
	    
    esac
         
  
  fi
  
  IFS=$saveIFS

}


#------------------------------------------------------------------------------#
#Synoptique:Operation [feuille de calcul]
#permet de découper la feuille en ligne, affecter chaque ligne aux variables 
#positionnelles, maintenant découper chaque ligne en cellules pour récupérer
#les différentes opérations à effectuer.
#------------------------------------------------------------------------------#

function RechercheOperation ()
{
local saveIFS
local ligne=""

 #je compte le nombre de ligne de notre fichier.
 nbLigne=`wc -l "$1" | cut -d " " -f 1`

 #Je recupère le contenu du fichier.
 fichier=`cat "$1"`
 
 #Je change l'IFS pour positionner les lignes de notre fichier dans les variables arguments.
 ChangerIFS "$sep_lig_ini"
 
 #Je repositionne de nouvelles valeures dans les variables arguments.
 set -- $fichier
 
 i=0
 j=0

 #while [  $nbLigne -ne $i  ] ; do

 while [ $nbLigne -ge $i  ] ; do

 
	  if [  ! -z $1   ]; then
		  #Je change l'IFS pour positionner les lignes de notre fichier dans les variables arguments.
		  ChangerIFS "$sep_col_ini"
		  set -- $1
		 value=$#
		 value=`expr $value + 1`
	        while [  $value  -ne  0 ] ; do

                             #Je recherche le signe égal.
			     val1=$1
			     val2=${val1:0:1}

				if  [  "$val2" == "="  ] ; then
				

				          Operation $val1
						ligne="$ligne $res"

				else 
					ligne="$ligne $val1"

                                       
		
	    			fi
	    		       
	             value=`expr $value - 1`
	     			shift
	        done
	     
	       
                  `echo $ligne >> $fic_res`  
        	     
			 
	 fi
       
       #Je change l'IFS pour positionner les lignes de notre fichier dans les variables arguments.
       ChangerIFS "$sep_lig_ini"
       #Je repositionne de nouvelles valeures dans les variables arguments.
       set -- $fichier
       shift $i
       i=`expr "$i" + 1`
	ligne=""
 done



}



RechercheOperation "$fic_ini"

#------------------------------------------------------------------------------#
#Un compteur est incrémenté si la fonction display est appelé dans la feuille de 
#calcul, si ce n'est pas le cas alors le programme affiche la feuille de calcul
#en entière
#------------------------------------------------------------------------------#

#if [ $cptdis -eq 0 ]; then
##	echo `cat $fic_res`
#fi


