#include "stdio.h"
#include "unistd.h"
#include "stdlib.h"
#include "pthread.h"
#include "sys/ipc.h"
#include "sys/sem.h"
#include "sys/types.h"

#define NB_PHILO 5 
#define NB_REPAS 3 
#define CHECK(sts,msg) if ((sts) == -1) {perror(msg); exit(-1); }

int sem;
pthread_mutex_t MUTEX;
typedef enum{P, M, A}T_Etat; 
T_Etat *Etat;

int NBP = NB_PHILO;
int NBR = NB_REPAS;


int  _P(int id);
int  _V(int id);
void Affichage();
int  newSemaphore();
void *Philo(void * p );
void Penser(int Num_Philo);
void Manger(int Num_Philo);
void Tester (int Num_Philo);
int  Voisin_Droite(int Numero);
int  Voisin_Gauche(int Numero);


int main(void)
{
      int i;
      pthread_t* PHILOSOPHE;
      void *ret;
      NBP= NB_PHILO;
      NBR= NB_REPAS;
      int Num_Repas = 1;
      while(NBR != Num_Repas-1)
      {
            printf("\n\t\tRepas : %i \n", Num_Repas);
            Etat = (T_Etat * ) malloc(NBR *sizeof(T_Etat));
            PHILOSOPHE = (pthread_t * ) malloc(NBP *sizeof(pthread_t));
            sem = newSemaphore();
            for ( i=0; i<NBP; i++){
                  CHECK(semctl(sem,i,SETVAL,0),"Problème initialisation sémaphore - semctl()");
                  Etat[i]= P;
            }
            for ( i=0; i<NBP; i++)
            {
                  CHECK(pthread_create(&PHILOSOPHE[i], NULL, (void *)Philo,(void *)i), "Problème création");
            }
            for ( i=0; i<NBP; i++)
            {
                  CHECK(pthread_join(PHILOSOPHE[i], &ret),"Problème jointure");
            }
            Num_Repas ++;
      }
      exit(EXIT_SUCCESS);
}

int Voisin_Droite(int Numero)
{
      int Numero_Droite = Numero+1;
      if (Numero_Droite == NB_PHILO)
      {
            Numero_Droite=0;
      }
      return Numero_Droite;
}

int Voisin_Gauche(int Numero)
{
      int Numero_Gauche = Numero-1;
      if (Numero_Gauche==-1)
      {
            Numero_Gauche=NB_PHILO-1;
      }
      return Numero_Gauche;
}

void Affichage()
{
      int i = 0;
      for (i= 0; i< NB_PHILO; i++)
      {
            if (Etat[i] == 0) printf("%i Pense  | ",i);
            if (Etat[i] == 1) printf("%i Mange  | ",i);
            if (Etat[i] == 2) printf("%i A faim | ",i);
      }
      printf("\n");
}

void Tester (int Num_Philo)
 {

      if (Etat[Num_Philo]== A && Etat[Voisin_Droite(Num_Philo)]!= M && Etat[Voisin_Gauche(Num_Philo)]!=M)
      {
	      Etat[Num_Philo] = M;
	      Affichage();
	      CHECK(_V(Num_Philo),"Problème incrémentation sémaphore");
      }
}

void Penser(int Num_Philo)
{
      sleep(rand()%NB_PHILO);
}

void Manger(int Num_Philo)
{
      sleep(rand()%NB_PHILO);
}

void *Philo(void * p )
{ 

      int Num_Philo = (int) p;

      Penser(Num_Philo);

      pthread_mutex_lock(&MUTEX);

      Etat[Num_Philo] = A;

      Affichage();

      Tester(Num_Philo);

      pthread_mutex_unlock(&MUTEX);

      CHECK(_P(Num_Philo),"Problème attente sémaphore");

      Manger(Num_Philo);

      pthread_mutex_lock(&MUTEX);

      Etat[Num_Philo] = P;

      Affichage();

      Tester(Voisin_Droite(Num_Philo)); 

      Tester(Voisin_Gauche(Num_Philo));

      pthread_mutex_unlock(&MUTEX);

      pthread_exit(0);
}

int _P(int indentifiant){

struct sembuf sembuf;

sembuf.sem_num = indentifiant;

sembuf.sem_op = -1;

sembuf.sem_flg = SEM_UNDO;

return semop(sem,&sembuf,1);

};

int _V(int indentifiant){

struct sembuf sembuf;

sembuf.sem_num = indentifiant;

sembuf.sem_op = 1;

sembuf.sem_flg = SEM_UNDO;

return semop(sem,&sembuf,1);

};


int newSemaphore(){
static int id = 0;
 key_t key;
 int semaphore;

 if((key = ftok("/bin/ls",id++)) == -1)
 {
   perror("Erreure de création de clé - ftok()");
   exit(EXIT_FAILURE);
 }
 
 if(((semaphore = semget(key,NBP,IPC_CREAT|IPC_EXCL|0600)) == -1) || ((semaphore = semget(key,NBP,0600)) == -1))
 {
    perror("Erreur de création de sémaphore - semget()");
    exit(EXIT_FAILURE);
 }

 return semaphore;
 
}


