/**************************************/
/****** DEFINITION DE BIBLIOTHEQUE ****/
/**************************************/
#define _GNU_SOURCE /*Pour utiliser get_current_dir_name()*/
#include "unistd.h" /*get_current_dir_name()*/
#include "errno.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "sys/wait.h"
#include "ctype.h"
#include "assert.h"
#include "string.h"
#include "fcntl.h" /* fonction open() et macros */
#include "sys/types.h"
#include "signal.h" /* gestion des signaux*/

/*pour gérer la fonction readline et l'historique :
 *intaller d'abord le paquet suivant sudo apt-get install libreadline-dev
 *pour la compilatioin: gcc -Wall shell.c -shell -lreadline -g
 */
#include "readline/readline.h"
#include "readline/history.h"

/**************************************/
/*** VARIABLE GLOBALE ET MACROS *******/
/**************************************/

#define FIN_FILS     2
#define ERREUR_EXEC  127
#define CHECK(str) { \
                     perror(str);\
                     exit(EXIT_FAILURE);\
                    }

#define RED      31
#define GREEN    32
#define YELLOW   33
#define BLUE     34
#define WHITE    35
#define TRUE     1
#define FALSE    0
char* dir              = NULL;
char **commande        = NULL;
int pointVirgule       = 0;
int etCommerciale      = 0;
int alternative        = 0;
int caracterePipe      = 0;
char* ligneCommande    = NULL;
volatile int fg_pid    = -1;



/**************************************/
/******* PROTOTYPE DE FONCTION ********/
/**************************************/
void init();
char* prompt(void);
void  execPipe(int i);
char  *trim (char *str);
void  cd(char*pathname);
void  sequenceAlternative();
int   isSequenceAlternative();
void  child_signal(int signal);
void  handler_ctrc(int signal);
int   isPipe(char * ligneCommande);
void  waitChild(pid_t pid, int status);
char* colorer(int typeColor,char* texte);
char  **recupererCommande (char *s, const char *ct);

int main(){
    

     pid_t pid; 
     
     int status = 0;
     char ** options = NULL;
     char** commandeRepertoire = NULL;
     
     using_history();
     signal(SIGINT,handler_ctrc);
     signal(SIG_BLOCK,child_signal);
          
       
       
 
     while(TRUE)
     {	

        /* Je vide l'entrée standard. */
        fflush(stdin);
        
        /*Initialisation des variables*/
        init();
        
        ligneCommande = readline((const char*)colorer(BLUE,(char*)prompt()));
        
        /* j'ajoute ma commande dans mon historique. */
        add_history(ligneCommande);
        
       if(!strncmp(ligneCommande,"exit",4) || !strncmp(ligneCommande,"quit",4) || !strncmp(ligneCommande,"q",1)) 
       {             
             exit(EXIT_SUCCESS);
       }
        
        else if ((strncmp(ligneCommande,"cd", 2))==0) 
        { 
                commandeRepertoire = recupererCommande(ligneCommande," ");
                if (strncmp(commandeRepertoire[1] , "~" ,1) == 0)
                {
                    dir = getenv("HOME");
                }
                else
                {
                    dir = commandeRepertoire[1];
                }
                if (chdir(dir) == 0) 
                {
                    dir = getcwd(NULL, 0);
                } 
                else
                {
                    fprintf(stderr,"%s directory change failed\n",commandeRepertoire[1]);
                }
        }
        else
        {
                if(isPipe(ligneCommande))
                {  
                    execPipe(0);                  
                }
                else if(isSequenceAlternative())
                {
                   sequenceAlternative();
                }
                else 
                {      
                       pid = fork();

                       if(pid == -1)
                       {
                         CHECK("Erreure Création de Processus: ");
                       }
                        
                
                        if(pid == 0)
                        { 
                                               
                                                      
                                   options = recupererCommande(ligneCommande, " ");
                                   execvp((const char*)options[0],options);
                                   perror("Erreur de la fonction execvp");
                                   exit(ERREUR_EXEC);
                        }
                        else
                        {
                                  free(ligneCommande);
                                  waitChild(pid,status);
                        }
                } 
        }

        
        
  }
     
     return EXIT_SUCCESS;

}

void waitChild(pid_t pid, int status){
  pid_t ret;

	  ret = waitpid(pid, &status,WUNTRACED | WCONTINUED);
	  if(ret == -1)
	  {
	     CHECK("Erreure Creation de Processus: ");
	  }
	  
	  if(WIFEXITED(status)) 
	  { 
	      if(status == FIN_FILS)
	      {
	          
	          printf("Vous quittez le programme de PID: %d en renvoyant le code:  %d\n", pid,WEXITSTATUS(status));
	          exit(EXIT_SUCCESS);
	      }
	      else
	      {
         	  printf("Le Fils de PID: %d se termine normalement avec le code:  %d\n", pid,WEXITSTATUS(status));
              }
	  }
	  else if(WIFSIGNALED(status))
	  {
	      printf("Le Fils de PID: %d est tué par le signal %d\n", pid,WTERMSIG(status));
	  }
	  else if(WIFSTOPPED(status)) 
	  { 
	      printf("e Fils de PID: %d est stoppé par le signal %d\n",pid, WSTOPSIG(status));
	  }
	  else if(WIFCONTINUED(status))
	  {
              printf("Processus %d relancé\n",pid);
          }

}


char **recupererCommande (char *s, const char *ct){
   char **tab = NULL;

   if (s != NULL && ct != NULL)
   {
      int i;
      char *cs = NULL;
      size_t size = 1;
      for (i = 0; (cs = strtok (s, ct)); i++)
      {
         if (size <= i + 1)
         {
            void *tmp = NULL;
            size <<= 1;
            tmp = realloc (tab, sizeof (*tab) * size);
            if (tmp != NULL)
            {
               tab = tmp;
            }
            else
            {
               fprintf (stderr, "Memoire insuffisante\n");
               free (tab);
               tab = NULL;
               exit (EXIT_FAILURE);
            }
         }
         tab[i] = trim(cs);
         s = NULL;
      }
      tab[i] = NULL;
 }
   return tab;
}

void init(){

dir                = NULL;
commande           = NULL;
pointVirgule       = 0;
etCommerciale      = 0;
alternative        = 0;
caracterePipe      = 0;
ligneCommande      = NULL;
fg_pid             = -1;


}
void cd(char*pathname){

  char** commande = NULL;
  if ((strncmp(pathname,"cd", 2))==0) 
  { 
      commande = recupererCommande(pathname," ");
        if (strncmp(commande[1] , "~" ,1) == 0)
        {
            dir = getenv("HOME");
        }
        else
        {
            dir = commande[1];
        }
        if (chdir(dir) == 0) 
        {
            dir = getcwd(NULL, 0);
        } 
        else
        {
            perror("directory change failed.\n");
        }
  }

}

char* prompt(void){

  return get_current_dir_name();

}

char* colorer(int typeColor,char* texte){

 char * texteCopie = (char*)malloc(sizeof(texte)+100);
 sprintf(texteCopie,"\033[01;%dm%s\033[0m ",typeColor,texte);
 return texteCopie;
 free(texteCopie);
 
}


void  handler_ctrc(int numSig){
    char rep;
    printf("\n%s ",colorer(GREEN,"Voulez vous quitter le programme (O/N)"));
    fflush(stdin);
    scanf("%c",&rep);
    if((rep == 'O') ||(rep == 'o'))
     {
         signal(numSig,SIG_DFL);
         raise(numSig);
     }

}


void child_signal(int signal) {
    /* un signal peut correspondre à plusieurs fils finis, donc on boucle */
    while (1) {
        printf(" wait %d\n",signal);
        int status;
        pid_t pid = waitpid(-1,&status,WNOHANG);
        if (pid<0) {
            if (errno==EINTR) continue; /* interrompu => on recommence */
            if (errno==ECHILD) break;   /* plus de fils terminé => on quitte */
            printf("erreur de wait : (%s)\n",strerror(errno));
            break;
        }

        if (pid==0) break; /* plus de fils terminé => on quitte */

        /*  signale à execute que fg_pid s'est terminé */
        if (pid==fg_pid) fg_pid = -1;

        if (WIFEXITED(status))
            printf("terminaison normale, pid=%i, status %i\n",pid,WEXITSTATUS(status));
        if (WIFSIGNALED(status))
            printf("terminaison par signal %i, pid=%i\n",WTERMSIG(status),pid);
    }
}


char *trim (char *str)
{
   char *ibuf, *obuf;
 
   if (str)
   {
      for (ibuf = obuf = str; *ibuf;)
      {
         while (*ibuf && (isspace (*ibuf)))
         {
            ibuf++;
         }
         if (*ibuf && (obuf != str))
         {  
            *(obuf++) = ' ';
         }
         
         while (*ibuf && (!isspace (*ibuf)))
         {
            *(obuf++) = *(ibuf++);
         }
         
      }
      *obuf = '\0';
   }
   return str;
}

void sequenceAlternative(){

 int i = 0;
 char ** commandes = NULL;
 char ** opt = NULL;
 char * line = NULL;
 int status = 0;
 
 pid_t pid;
 

 line = strdup(ligneCommande);
 
 if(pointVirgule)
 {
      commandes = recupererCommande(line,";");
 }
 else if(etCommerciale)
 {
      commandes = recupererCommande(line,"&&");
 }
 else if(alternative)
 {
     commandes = recupererCommande(line,"||");
 }
 
 
while(commandes[i]) {
       pid = fork();
         
         if(pid == -1)
         {
                   CHECK("Erreure creation fork() ");
         }
 
        if( pid == 0 )
         {
                   opt = recupererCommande(commandes[i]," ");
                   execvp((const char*)opt[0],opt);                            
         }
         else
         {
                   waitChild(pid,status);
                   if(etCommerciale)
                   {
                             if(status)
                             {
                                exit(EXIT_FAILURE);
                             }
                   }
                   else if(alternative)
                   {
                             if(!status)
                             {
                               exit(EXIT_SUCCESS);
                             }
                   }
         }

   i++;      
}

free(line);

}

int isSequenceAlternative(){

        if(strchr(ligneCommande,';')) 
         {
           pointVirgule  = 1; 
         }
         else if(strstr(ligneCommande,"&"))
         {
           etCommerciale = 1;
         }
         else if(strstr(ligneCommande,"||"))
         {
           alternative = 1;
         }
         
         if(pointVirgule ||  etCommerciale || alternative )
         {
             return TRUE;   
         }
         else
         {
            return FALSE;
         }        
}

void execPipe(int i){

pid_t pid;
int p[2];
char ** opt;

 if(commande[i])
 {
    opt = recupererCommande(commande[i]," ");
    if(pipe(p) == -1)
    {
      CHECK("Erreure pipe()");
    }
           
   if (caracterePipe != i) 
   {
         
         pid = fork();
         
         if(pid == -1)
         {
            CHECK("Erreure creation fork() ");
         }
 
		if(!pid)
		 { 
		          close(p[1]);
                          dup2(p[0], STDIN_FILENO);
                          close(p[0]);
		          execPipe(i+1);
		 }
		 else
		 {
		         close(p[0]);
                         dup2(p[1], 1);
                         close(p[1]);
		         execvp((const char*)opt[0],opt);
		 }      
     }
     else
     {
        close(p[0]);
        execvp((const char*)opt[0],opt);
     }
 }

}

int isPipe(char * ligneCommande){
char * ret;
char * line = NULL;

line = strdup(ligneCommande);
commande = recupererCommande(line,"|");
if((ret = strchr(ligneCommande,'|')) && (*(ret+1)!= '|'))
 {
           while(*ligneCommande)
           {
               if(*ligneCommande == '|')
               {
                  caracterePipe++;
               }
               ligneCommande++;
           }
   
 }
 
 if(caracterePipe)
 {
      return 1;   
 }
 else
 {
     return 0;
 }
 
 free(line);
 
 }
