#define _GNU_SOURCE 								/*pour utiliser get_current_dir_name()*/
#include "pwd.h"
#include "grp.h"								/*affichage de l'id du groupe des fichiers et dossiers*/
#include "glob.h"        							/* gestion des méta-caractères.*/
#include "time.h"
#include "ctype.h"
#include "fcntl.h"       							/* fonction open() et macros */
#include "errno.h"								/*pour l'utilisation de perror*/
#include "stdio.h"
#include "stdlib.h"
#include "dirent.h"
#include "string.h"
#include "signal.h"      							/* gestion des signaux*/
#include "dirent.h"      							/* opendir */
#include "unistd.h" 								/*get_current_dir_name()*/
#include "sys/ipc.h"
#include "sys/sem.h"
#include "sys/wait.h"								/*attente de la mort des processus fils*/
#include "sys/stat.h"								/*les droits des fichiers et dossiers*/
#include "sys/types.h"
#include "sys/times.h" 
#include "Fonction.h"
										/*Déclaration de mon tableau de chevron*/
char * tableauChevron[] = {							
                         ">",">k","2>",
                         ">>","2>>",">>k",
                         ">"
                        };

void  gestion_ctrz(int numSignale){				/*gestion du signal ctrl + z , reçoit en param le num du signal*/
int i   = 0; 
pid_t pid;

CHECK((pid = waitpid(-1,NULL,WNOHANG)), "Erreure waitpid() - gestionFils()");

ElementTable* proc = (ElementTable*)recupererElement(P,(int)pid);		/*on recherche si le processus existe déjà*/

if( (proc != NULL) && (proc->type == foreGround) ){				/*donc le processus existe et est en foreground*/

while(i < P->N)									/*parcours du tableau P*/
{
  if(P->Element[i].pid == pid)
   {
          P->Element[i].numJob = ++numeroJob;					/*on incremente le numéro du job à la position i*/
          fprintf(stdout,"la commande %s devient le job %d est Stoppé",
          P->Element[i].nomProc,P->Element[i].numJob);
          kill(P->Element[i].pid,SIGTSTP);   					/*on tue le processus se trouvant à la position i*/
          break;
   }
   i++;
}

}
printf("%s",(const char*)colorer(BLUE,(char*)prompt()));


}

void  sortieShell(void)								/*pour sortir du shell*/
{
  int i = 0;
  while(i < P->N) kill(P->Element[i++].pid,SIGKILL);				/*tue tous les processus stockés dans le tableau P*/
  detruireTable(P);								/*destruction du tableau P lui même*/
  free(ligneCommande);                                                          /*on libère le prompt*/
}

void gestionFils(int numSignale){
pid_t pid;
int i = 0;
int cpSig = numSignale;

printf("\n");
CHECK((pid = wait(&status)), "Erreure waitpid() - gestionFils()");

ElementTable* proc = (ElementTable*)recupererElement(P,(int)pid);		/*on recherche si le processus existe déjà*/

if(proc == NULL){								/*si le processus n'existe pas*/
  
if(!strlen(*opt))								
  strcpy(opt[0],"unknow process");
ElementTable elt = creerElement((int)pid,foreGround,-1,opt[0],"S");		/*on va insérer le processus dans la table*/

insererDsTable(P,&elt);
}
else										/*si le processus existe*/
{
        if(numSignale) numSignale = -1;						/*on remet le signal à -1*/

        if((proc!= NULL) && (proc->type == backGround))				
        {									/*si le processus est en background*/
         
                 printf("%s (jobs[%d] , pid = %d) terminé avec status = %d (%s)\n",
                 proc->nomProc,proc->numJob,pid,numSignale,strsignal(cpSig));
                  
                 
                 while(i< P->N)							
                 {				/*on enlève le processus de ma table: SuprimerElement(Processus *P, int pid)*/
                 
                              if((P->Element[i].pid == pid) && (P->Element[i].type == backGround))
                               {
                                         P->Element[i].pid     = 0 ;
                                         P->Element[i].type    = 0 ;
                                         P->Element[i].numJob  = 0 ;
                                         strcpy(P->Element[i].nomProc," ");
                                         strcpy(P->Element[i].state," ") ;
                               }
                               else if((P->Element[i].type == backGround))
                               {
                                         if(P->Element[i].numJob == 1)
                                         {
                                           continue;
                                         }
                                         else
                                         {
                                           --P->Element[i].numJob;
                                         }
                               }
                           i++;
                 }
                --numeroJob;

        }
 }

}

void arrierePlan(char *ligne){							/*lancement de processus en arrière plan*/
pid_t pid;
int fd,num;
char* tmp;
char buf[100];
char * stateJob = (char*)malloc(sizeof(char)*50);

CHECK((pid = fork()),"Erreure Creation fork() - arrierePlan()");
      numeroJob++;
      opt = recupererCommande(ligne,"&");
      if(!pid)
      {
        int devnull = open("/dev/null",O_RDONLY);
        if (devnull != -1) 
        {
          close(0);
          dup2(devnull,0);
          printf("[%d]  %d\n",numeroJob,getpid());
          execvp((const char*)opt[0],opt);
        }
      }
    
    snprintf(buf,32,"/proc/%d/stat",pid);
    CHECK((fd = open(buf,O_RDONLY,0)),"ERREURE open - myjobs() ");
    num    = read(fd, buf, sizeof buf -1);
    if(num < 80) exit(EXIT_FAILURE);
    buf[num] = '\0';
    tmp    = strrchr(buf, ')');     
    *tmp   = '\0';
    sscanf(tmp+2, "%s",stateJob); 
    ElementTable elt = creerElement((int)pid,backGround,numeroJob,opt[0],stateJob);
    insererDsTable(P,&elt);
 close(fd);
 free(stateJob);
}


void waitChild(pid_t pid, int status){				/*message d'informations après l'attente de la mort du fils*/
         
          pause();
	  
	  if(WIFEXITED(status)) 
	  { 
	      if(status == FIN_FILS)
	      {
	          
	          printf("Vous quittez le programme de PID: %d en renvoyant le code:  %d\n", pid,WEXITSTATUS(status));
	          exit(EXIT_SUCCESS);
	      }
	      else
	      {
         	  printf("Le Fils de PID: %d se termine normalement avec le code:  %d\n", pid,WEXITSTATUS(status));
              }
	  }
	  else if(WIFSIGNALED(status))
	  {
	      printf("Le Fils de PID: %d est tué par le signal %d\n", pid,WTERMSIG(status));
	  }
	  else if(WIFSTOPPED(status)) 
	  { 
	      printf("e Fils de PID: %d est stoppé par le signal %d\n",pid, WSTOPSIG(status));
	  }
	  else if(WIFCONTINUED(status))
	  {
              printf("Processus %d est relancé\n",pid);
          }

}


char **recupererCommande (char *s, const char *ct){				/*la fonction split : crée un tableau de chaîne de car avec ligneCommande*/
   char **tab = NULL;

   if (s != NULL && ct != NULL)
   {
      int i;
      char *cs = NULL;
      size_t size = 1;
      for (i = 0; (cs = strtok (s, ct)); i++)
      {
         if (size <= i + 1)
         {
            void *tmp = NULL;
            size <<= 1;
            tmp = realloc (tab, sizeof (*tab) * size);
            if (tmp != NULL)
            {
               tab = tmp;
            }
            else
            {
               fprintf (stderr, "Memoire insuffisante\n");
               free (tab);
               tab = NULL;
               exit (EXIT_FAILURE);
            }
         }
         tab[i] = trim(cs);
         s = NULL;
      }
      tab[i] = NULL;
 }
   return tab;
}

void init(){									/*on réinitialise les variables*/

opt                 = NULL;
dir                 = NULL;
commande            = NULL;
pointVirgule        = 0;
etCommerciale       = 0;
alternative         = 0;
caracterePipe       = 0;
chevronDroit        = 0;
chevronGauche       = 0;
chevronDouble       = 0;
ligneCommande       = NULL;
caractereBackground = 0;


}



char* prompt(void){								/*le prompt*/

  return get_current_dir_name();

}

char* colorer(int typeColor,char* texte){					/*Pour les couleurs*/

 char * texteCopie = (char*)malloc(sizeof(texte)+100);
 sprintf(texteCopie,"\033[01;%dm%s\033[0m ",typeColor,texte);
 return texteCopie;
 free(texteCopie); 
}


void  handler_ctrc(int numSig){							/*controle du signal CRTL + C*/
    char rep;
    printf("\n%s ",colorer(GREEN,"Voulez vous quitter le programme (O/N)"));
    fflush(stdin);
    scanf("%c",&rep);
    if((rep == 'O') ||(rep == 'o') || (rep == 'Y') || (rep == 'y'))
     {
         signal(numSig,SIG_DFL);
         raise(numSig);
         exit(EXIT_SUCCESS);
     }
     else
     {
       /*Je réaffiche l'invite de commande.*/
       printf("%s",(const char*)colorer(BLUE,(char*)prompt()));
     }

}



char *trim (char *str)
{
   char *ibuf, *obuf;
 
   if (str)
   {
      for (ibuf = obuf = str; *ibuf;)
      {
         while (*ibuf && (isspace (*ibuf)))
         {
            ibuf++;
         }
         if (*ibuf && (obuf != str))
         {  
            *(obuf++) = ' ';
         }
         
         while (*ibuf && (!isspace (*ibuf)))
         {
            *(obuf++) = *(ibuf++);
         }
         
      }
      *obuf = '\0';
   }
   return str;
}


void sequenceAlternative(){							/*partie sequencement*/

 int i = 0;
 char* copyCommande = NULL;
 char **  commandes = NULL;
 char * line = NULL;
 char *ret = NULL; 
 pid_t pid;
 

 line = strdup(ligneCommande);
 
 if(pointVirgule)
 {
      commandes = recupererCommande(line,";");			/*insére dans commande à chaque fois qu'on rencontre ";" dans line*/
 }
 else if(etCommerciale)
 {
      commandes = recupererCommande(line,"&&");			/*insére dans commande à chaque fois qu'on rencontre "&&" dans line*/
 }
 else if(alternative)
 {
     commandes = recupererCommande(line,"||");			/*insére dans commande à chaque fois qu'on rencontre "||" dans line*/
 }
 
 
while(commandes[i]) {
       pid = fork();
         
        CHECK(pid,"Erreure creation fork() ");       
        
        copyCommande = strdup(commandes[i]);
        
        opt = recupererCommande(commandes[i]," ");   /*à chaque fois qu'on rencontre le séparateur " ",on insère dans le tableau opt*/
		 
        if( pid == 0 )
         {                 
                if((ret = strchr(copyCommande,'&')) && (*(ret+1)!='&'))
                {
                    arrierePlan(copyCommande);					/*Background*/
                }
                else if(isRedirection(copyCommande))
                {
                   strcpy(ligneCommande,copyCommande);
                   execRedirection();
                }
                else if(isPipe(copyCommande))					
                {  
                    strcpy(ligneCommande,copyCommande);				/*si c'est un tube*/
                    execPipe(0);                  
                }
                else if(strchr(copyCommande,'*'))				
                {  
                  glob_t chemins = (glob_t)gestionWildCar(copyCommande);	/*gestion des jocker : wilcards*/
		  
		  for(i=0; i<chemins.gl_pathc; i++)
		  {
		    fprintf(stdout, "%s\n", chemins.gl_pathv[i]);
		  }
		  if(!chemins.gl_pathc)
		  {
		     exit(EXIT_FAILURE);
		  }
		  else
		  {
		     exit(EXIT_SUCCESS);
		  }
                  globfree(& chemins);		  
                }
                else
                {  
                   execvp((const char*)opt[0],opt);				/*exécution sequence par sequence*/
                }                          
         }
         else
         {
                   waitChild(pid,status);
                   if(etCommerciale)
                   {
                             if(status)
                             {
                                break;
                             }
                   }
                   else if(alternative)
                   {
                             if(!status)
                             {
                               break;
                             }
                   }
         }
         
   i++;      
}

free(ret);									/*libération des ressources*/
free(line);
free(copyCommande);
}


int isSequenceAlternative(char* ligne){						/*définition des sequences alternatives*/

        if(strchr(ligne,';')) 
         {
           pointVirgule  = 1; 
         }
         else if(strstr(ligne,"&&"))
         {
           etCommerciale = 1;
         }
         else if(strstr(ligne,"||"))
         {
           alternative = 1;
         }
         
         if(pointVirgule ||  etCommerciale || alternative )
         {
             return TRUE;   
         }
         else
         {
            return FALSE;
         }        
}

void execPipe(int i){								/*exécution des tubes*/
pid_t pid;
int p[2];
char *ret = NULL; 
char * copyCommande = NULL;

 if(commande[i])
 {
    copyCommande = strdup(commande[i]);    

    opt = recupererCommande(commande[i]," ");
    
    CHECK(pipe(p),"Erreure pipe()");
           
   if (caracterePipe != i) 
   {
         
         pid = fork();
         
         CHECK(pid,"Erreure creation fork() ");
         
         if(pid == 0)
         { 
              close(p[1]);
              dup2(p[0], STDIN_FILENO);
              close(p[0]);
	      execPipe(i+1);
         }
         else
	 {	     
	        close(p[0]);
                dup2(p[1], 1);
                close(p[1]);
                  
                if((ret = strchr(copyCommande,'&')) && (*(ret+1)!='&'))		
                {
                          arrierePlan(copyCommande);				/*lancement de procussus en background*/
                }
                else if(isRedirection(copyCommande))				
                {
                          strcpy(ligneCommande,copyCommande);			/*redirection*/
                          execRedirection();
                }
                else if(isSequenceAlternative(copyCommande))			
                {
                          strcpy(ligneCommande,copyCommande);			/*sequence alternative*/
                          sequenceAlternative();
                }
                else if(strchr(copyCommande,'*'))				
                {  								/*les wilcards*/
                
                          glob_t chemins = (glob_t)gestionWildCar(copyCommande);
		          
		          for(i=0; i<chemins.gl_pathc; i++)
		          {
		            printf("%s\n", chemins.gl_pathv[i]);
		          }
		          if(!chemins.gl_pathc)
		          {
		              exit(EXIT_FAILURE);
		          }
		          else
		          {
		              exit(EXIT_SUCCESS);
		          }
		          globfree(& chemins);
                }
                else
                {
                         execvp((const char*)opt[0],opt);
                }
         }       
     }
     else
     {     
        close(p[0]);
        if((ret = strchr(copyCommande,'&')) && (*(ret+1)!='&'))			
        {
                 arrierePlan(copyCommande);					/*lancementdu processus en background*/
        }
        else if(isRedirection(copyCommande))					
        {
                 strcpy(ligneCommande,copyCommande);				/*redirection*/
                 execRedirection();
        }
        else if(isSequenceAlternative(copyCommande))				
        {
                strcpy(ligneCommande,copyCommande);				/*sequence alternative*/
                sequenceAlternative();
        }
        else if(strchr(copyCommande,'*'))					
        {  
            glob_t chemins = (glob_t)gestionWildCar(copyCommande);		/*les wilcards*/
		          
	    for(i=0; i<chemins.gl_pathc; i++)
            {
		printf("%s\n", chemins.gl_pathv[i]);
            }
            
             if(!chemins.gl_pathc)
	     {
		exit(EXIT_FAILURE);
	     }
	     else
	     {
		exit(EXIT_SUCCESS);
             }
	    globfree(& chemins);
        }
        else
        {
             execvp((const char*)opt[0],opt);
        }
        
     }
     
  }
    
}

int isPipe(char* ligneCommande){						/*reconnaître un pipe*/
char * ret  = NULL;
char * line = NULL;

if(ligneCommande)
{
        line = strdup(ligneCommande);
        commande = recupererCommande(line,"|");
        
        if((ret = strchr(ligneCommande,'|')) && (*(ret+1)!= '|'))
         {
                   while(*ligneCommande)
                   {
                       if(*ligneCommande == '|')
                       {
                          caracterePipe++;
                       }
                       ligneCommande++;
                   }
           
         }
} 
 if(caracterePipe)
 {
      return TRUE;   
 }
 else
 {
     return FALSE;
 }

 free(ret);
 free(line);
 
 }
 
int isRedirection(char* ligneCommande){						/*reconnaître une redirection*/
char *ret = NULL;
char* ligne = strdup(ligneCommande);


	if( (ret = strchr(ligne,'>')) && (*(ret+1) != '>'))
	{
	  chevronDroit = 1;
	}
	else if(strstr(ligne,"<"))
	{
	  chevronGauche = 1;
	}
	else if(strstr(ligne,">>"))
	{
	  chevronDouble = 1;
	}

        if(chevronDroit ||  chevronGauche || chevronDouble)
         {
             return 1;   
         }
         else
         {
            return 0;
         }
 free(ret);
 free(ligne);	
}

void execRedirection(){								/*exécution des redirections*/

pid_t pid;
int i;
int fd;
char * fichier = NULL;
char ** ligne  = NULL; 
char * copyCommande = NULL;
typeChevron chevron;
char* cpCommande = strdup(ligneCommande);

if(chevronDroit){								/*chevron droit*/

          if(strstr(cpCommande, ">k"))
          {
             chevron.repChevron = strdup(">k");
             chevron.type = CHEVRON_SIMPLE_DROIT_K;
          }
          else if(strstr(cpCommande, "2>"))
          {
             chevron.repChevron = strdup("2>");
             chevron.type = CHEVRON_SIMPLE_DROIT_2;
          }
          else
          {
             chevron.repChevron = strdup(">");
             chevron.type = CHEVRON_SIMPLE_DROIT;
          }

}
else if(chevronGauche){								/*chevron gauche*/

          chevron.repChevron = strdup("<");
          chevron.type = CHEVRON_SIMPLE_GAUCHE;

}
else if(chevronDouble){								/*chevron double*/

        if(strstr(cpCommande, ">>k"))
          {
             chevron.repChevron = strdup(">>k");
             chevron.type = CHEVRON_DOUBLE_DROIT_K;
          }
          else if(strstr(cpCommande, "2>>"))
          {
             chevron.repChevron = strdup("2>>");
             chevron.type = CHEVRON_DOUBLE_DROIT_2;
          }
          else
          {
             chevron.repChevron = strdup(">>");
             chevron.type = CHEVRON_DOUBLE_DROIT;
          }

}


ligne = recupererCommande(cpCommande,chevron.repChevron); /*stocke commande dans mon tableau "ligne" avec comme separateur "chevron"*/

fichier = strdup(ligne[1]);

CHECK((pid = fork()),"ERREUR fork() - execRedirection()");

copyCommande = (char*)malloc( strlen(ligne[0]) + 1);

strcpy(copyCommande,ligne[0]);

opt = recupererCommande(ligne[0]," ");

if(!pid)
  {

    if(!strcmp(tableauChevron[chevron.type],">"))
    {
            fd = open(fichier,O_CREAT | O_TRUNC | O_WRONLY,0600);
            CHECK(fd,"ERREURE open()");
            dup2(fd, STDOUT_FILENO);
    }
    else if(!strcmp(tableauChevron[chevron.type],"2>"))
    {
            fd = open(fichier,O_CREAT | O_TRUNC | O_WRONLY,0600);
            CHECK(fd,"ERREURE open()");
            dup2(fd, STDERR_FILENO);
    }
    else if(!strcmp(tableauChevron[chevron.type],">k"))
    {
            fd = open(fichier,O_CREAT | O_TRUNC | O_WRONLY,0600);
            CHECK(fd,"ERREURE open()");
            dup2(fd, STDOUT_FILENO|STDERR_FILENO);
    }
    else if(!strcmp(tableauChevron[chevron.type],">>"))
    {
            fd = open(fichier,O_APPEND | O_WRONLY,0600);
            CHECK(fd,"ERREURE open()");
            dup2(fd, STDOUT_FILENO);
    }
    else if(!strcmp(tableauChevron[chevron.type],"2>>"))
    {
            fd = open(fichier,O_APPEND | O_WRONLY,0600);
            CHECK(fd,"ERREURE open()");
            dup2(fd, STDERR_FILENO);
    }
    else if(!strcmp(tableauChevron[chevron.type],">>k"))
    {
            fd = open(fichier,O_APPEND | O_WRONLY,0600);
            CHECK(fd,"ERREURE open()");
            dup2(fd, STDOUT_FILENO|STDERR_FILENO);
    }
    else if(!strcmp(tableauChevron[chevron.type],"<"))
    {
            fd = open(fichier,O_CREAT | O_TRUNC | O_RDONLY,0600);
            CHECK(fd,"ERREURE open()");
            dup2(fd, STDIN_FILENO);
    }
    
    close(fd);
        
        if(isPipe(copyCommande))
        {  
                strcpy(ligneCommande,copyCommande);
                execPipe(0);                  
        }
        else if(isSequenceAlternative(copyCommande))
        {
                strcpy(ligneCommande,copyCommande);
                sequenceAlternative();
        }
        else if(strchr(copyCommande,'*'))
        {  
            glob_t chemins = (glob_t)gestionWildCar(copyCommande);
		          
	    for(i = 0; i<chemins.gl_pathc; i++)
            {
		printf("%s\n", chemins.gl_pathv[i]);
            }
            
            if(!chemins.gl_pathc)
	     {
		exit(EXIT_FAILURE);
	     }
	     else
	     {
		exit(EXIT_SUCCESS);
             }
	    globfree(& chemins);
        }
        else
        {
             execvp((const char*)opt[0],opt);
        }
 }
 else
 {
    waitChild(pid,status);
 }



free(ligne);
free(fichier);
free(copyCommande);
free(chevron.repChevron);

}

Processus* initTable(int NMax){

        Processus* P = (Processus*)malloc(sizeof(Processus));
        P->NMax      = NMax;
        P->N         = 0;
        P->Element   = (ElementTable*)malloc(sizeof(ElementTable)*NMax);
        return P;
}

ElementTable creerElement(int p,int t,int numJob,char *str,char*state){  	/*creation d'un tableau contenant les propriétés d'un preocessus*/
 
  ElementTable elt; 
  elt.pid          = p;
  elt.type         = t;
  elt.numJob       = numJob;
  elt.nomProc      = (char*)malloc(strlen(str)+1);
  strcpy(elt.nomProc,str);
  elt.state        = (char*)malloc(strlen(state)+1);
  strcpy(elt.state,state);

  return elt;
  
}


        
void detruireTable(Processus*P){						/*detruction d'un tableau d'un processus passé en paramétre*/
free(P->Element);
free(P);
}

void insererDsTable(Processus *T,ElementTable *new_element){	/*insertion d'un tableau d'un processus dans le tableau des processus */

 if(T->N < T->NMax)
 {
   T->Element[T->N++] = *new_element;
 }

}


ElementTable* recupererElement(Processus* T,int pid){				/*recherche d'un processus dans le tableau des processus*/
  int i      = 0;
  int trouve = 0;
  while((i < T->N) && !trouve)
  {
    if(T->Element[i].pid == pid)
    {
       trouve = 1;
    }
    
    if(!trouve)i++;
  }
  return trouve ? &P->Element[i] : NULL;
}

static diminuerAugmenterValeur(int val){				/* Diminuer ou Augmenter la valeur des jobs des processus.*/
 int i = 0;
 
 if(val < 0) val *= -1;
 while(i < P->N)
 {
   if(P->Element[i].type == backGround)
   {
      P->Element[i].numJob -=val;
   }
   i++; 
 }
 
}

void myjobs(Processus*P){							/*liste des jobs*/

int i   = 0; 

while(i < P->N)
{
  if(P->Element[i].type == backGround)
   { 
        printf("[%d]\t%d\t%s\t%s\n",
        P->Element[i].numJob,P->Element[i].pid,P->Element[i].state,P->Element[i].nomProc);
   }
   i++;
}


}

glob_t gestionWildCar(char* ligne){						/*gestion des wilcards*/
 
  glob_t chemins;
  int i      = 0;
  int erreur = 0;

  opt = recupererCommande(ligne, " ");
  erreur  = glob(opt[0], 0, NULL, & chemins);
  if((erreur != 0) && (erreur != GLOB_NOMATCH))
   {
     perror("Erreure metacartère - glob()");
     exit(EXIT_FAILURE);
   }
		  
   while (opt[i])
   {
      erreur = glob(opt[i], GLOB_APPEND, NULL, & chemins);
      if((erreur != 0) && (erreur != GLOB_NOMATCH))
      {
	perror("Erreure métacartère - glob()");
	exit(EXIT_FAILURE);
      }
      i++;
   }
   return chemins;
}

void mybg(){									/*le cas d'un background*/

int i = 0;
char out[256];
int plusGrand = 0;								/* Numero du processus le plus grand*/

  while(i < P->N)
  {
          if(P->Element[i].type == foreGround)
           {
                 plusGrand = i;
                 break;
           }
   i++;
  }
  
  P->Element[i].type = backGround;
  diminuerAugmenterValeur(1);  
}


void myfg(){									/*le cas d'un foreground*/

int i           = 0;
int plusAncien  = 1; 								/*Numero du processus le plus ancien*/
char out[256];

  while(i < P->N)
  {
          if(P->Element[i].type == backGround)
           {
             if(P->Element[i].numJob == plusAncien)
             {
                 diminuerAugmenterValeur(-1);
                 plusAncien    = P->Element[i].numJob;
                 break;
             }
             
           }
   
   i++;
  }

  if(P->Element[i].numJob == plusAncien)
   {
     if(P->Element[i].type != foreGround)
      {
        P->Element[i].type = foreGround;
                
        kill(P->Element[i].pid,SIGCONT);   
      }
   }
 
}

void _myfg(char * numPid){
int i = 0;
int plusAncien  = 1; 					/*mettre en foreground un processus dont le pid est passé en paramétre*/
char out[256];

if(atoi(numPid))
{
  while(i < P->N)
  {
          if(P->Element[i].type == backGround)
           {
             if((P->Element[i].pid == atoi(numPid)) && (P->Element[i].numJob == plusAncien))
             {
                 diminuerAugmenterValeur(-1);
                 plusAncien    = P->Element[i].numJob;
                 break;
             }
             
           }
   
   i++;
  }

  if(P->Element[i].numJob == plusAncien)
   {
     if(P->Element[i].type != foreGround)
      {
        P->Element[i].type = foreGround;
                
        kill(P->Element[i].pid,SIGCONT);   
      }
   }

} 

}

void _mybg(char * numPid){			/*mettre en background un processus dont le pid est passé en paramétre*/
int i = 0;
char out[256];
int plusGrand = 0;

if(atoi(numPid)){
  while(i < P->N)
  {
          if((P->Element[i].pid == atoi(numPid)) && (P->Element[i].type == foreGround))
           {
                 plusGrand = i;
                 break;
           }
   i++;
  }
  
  P->Element[i].type = backGround;
  diminuerAugmenterValeur(1); 

}

}
/* Fonction pour le calcul du temps processeur*/
const char *proc_time(unsigned long t){
  int hh,mm,ss;
  static char buf[32];
  int cnt = 0;
  t /= 100;
  ss = t%60;
  t /= 60;
  mm = t%60;
  t /= 60;
  hh = t%24;
  t /= 24;
  if(t) cnt = snprintf(buf, sizeof buf, "%d-", (int)t);
  snprintf(cnt + buf, sizeof(buf)-cnt, "%02d:%02d", mm, ss);
  return buf;
}

/*Fonction pour rcupérer les caractéristiques d'un processus.*/
void statProcessus(int pid,char*name){
    char* tmp;
    char buf[800];
    int fd;
    int num;
    double cp;
    clock_t debut_prog;
    struct tm * timestart = NULL;
    struct stat st;
    struct passwd *p = NULL;
    debut_prog = times(NULL);
    /*Ouverture du repertoire de numro pid*/
    snprintf(buf,32,"/proc/%d/stat",pid);
    if( (fd = open(buf,O_RDONLY,0)) == -1) exit(EXIT_FAILURE);
    num = read(fd, buf, sizeof buf -1);
    fstat(fd,&st);
    p = getpwuid(st.st_uid);
    close(fd);
    if(num < 80) exit(EXIT_FAILURE);
    buf[num] = '\0';
    tmp = strrchr(buf, ')');     
    *tmp = '\0';                 
    memset(proc.proc_name, 0, sizeof proc.proc_name);          
    sscanf(buf, "%d (%15c", &proc.proc_pid, proc.proc_name); 
    sscanf(tmp + 2,                    
       "%c "
       "%*d %*d %*d %d %*d "
       "%*d %*u %*u %*u %*u %lu %lu "
       "%*d %*d %*d %*d %*d %*d "
       "%lu %lu "
       "%ld ",
       &proc.proc_state,
       &proc.proc_tty_num,
       &proc.proc_utime,&proc.proc_stime,
       &proc.proc_start,&proc.proc_vsz, 
       &proc.proc_rss);
       
       proc.proc_rss*=(4096/1024);
       proc.proc_vsz/=1024;
       cp = times(NULL) - debut_prog;
       cp /=sysconf(_SC_CLK_TCK);
       timestart = localtime(&st.st_atime);
       
       sprintf(proc.proc_date,"%d:%01d",timestart->tm_hour,timestart->tm_min);
       
        memcpy(proc.proc_tty, "   ?   ", 8);
    if(proc.proc_tty_num != NO_TTY_VALUE) {
      int tty_maj = (proc.proc_tty_num>>8)&0xfff;
      int tty_min = (proc.proc_tty_num&0xff) | ((proc.proc_tty_num>>12)&0xfff00);
      if(tty_maj == 4)
      snprintf(proc.proc_tty, sizeof proc.proc_tty, "tty%-3d",tty_min);  
      else
      snprintf(proc.proc_tty, sizeof proc.proc_tty, "pts/%-3d",tty_min);  
    }
    sprintf(proc.proc_user,"%s",p->pw_name);
    
      printf( "%s\t%s\t%0.1lf\t"      
              "%0.1lf\t%lu\t%lu\t"     
              "%s\t%c\t%s\t"      
              "%s\t%s\n",
              proc.proc_user,name,cp,
              ((float)proc.proc_rss/(float)tailleMem)*100,proc.proc_vsz,proc.proc_rss,
              proc.proc_tty,proc.proc_state,proc.proc_date,
              proc_time(proc.proc_utime + proc.proc_stime),proc.proc_name);
             
}


/* Fonction pour le calcul %memoire*/
unsigned long mem(void){
int fd;
char buf[28];
unsigned long memoireTotale;
snprintf(buf,32,"/proc/meminfo");
if( (fd = open(buf,O_RDONLY,0)) == -1) exit(EXIT_FAILURE);
        if (read(fd, buf, sizeof buf -1) != 27 ) exit(EXIT_FAILURE);
                                        sscanf(buf,"%*10s %lu",&memoireTotale);     
                                        

close(fd);
return memoireTotale;

}

/*Fonction de gestion de myps*/
void myps(){

        DIR *dir = NULL;
        struct dirent *ent = NULL;
        /*Ouverture du repertoire proc système.*/
        dir = opendir("/proc");
        tailleMem  = mem();
        printf("USER\tPID\t%%CPU\t%%MEM\tVSZ\tRSS\tTTY\tSTAT\tSTART\tTIME\tCOMMAND\n");
        while( (ent= readdir(dir)))
        {

         if(atoi(ent->d_name))
                statProcessus(atoi(ent->d_name),ent->d_name);
        }
        closedir(dir);
}



void affiche_statusL (struct stat status,char * nom)				
{										/*exécution de myls "ls -l"*/
  
  struct passwd *pwd;
  struct group  *grp;
  DIR * ptdir;
  										/*eviter les fichiers cachés*/
  if(strncmp(nom, "..", 2) != 0 && strncmp(nom, ".", 1) != 0) 			
    {  										
      
      if(S_ISBLK(status.st_mode))						
	fprintf(stderr, "b");							/*affichage du type de fichier ou dossier*/
      else if(S_ISCHR(status.st_mode))
	fprintf(stderr, "c");
      else if(S_ISDIR(status.st_mode))
	fprintf(stderr, "d");
      else if(S_ISFIFO(status.st_mode))
	fprintf(stderr, "p");
      else if(S_ISLNK(status.st_mode))
	fprintf(stderr, "l");
      else if(S_ISREG(status.st_mode))
	fprintf(stderr, "-");
      else if(S_ISSOCK(status.st_mode))
	fprintf(stderr, "s");
      
      fprintf(stderr, status.st_mode & S_IRUSR ? "r" : "-");			/*affichage des droits*/
      fprintf(stderr, status.st_mode & S_IWUSR ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXUSR ? "x" : "-");
      fprintf(stderr, status.st_mode & S_IRGRP ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWGRP ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXGRP ? "x" : "-");
      fprintf(stderr, status.st_mode & S_IROTH ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWOTH ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXOTH ? "x" : "-");
      
      fprintf(stderr,"\t%ld",status.st_nlink);					/*affichage du lien*/
      
      if ((pwd = getpwuid(status.st_uid)) != NULL)				
	fprintf(stderr,"\t%s", pwd->pw_name);					/*id utilisateur*/
      if ((grp = getgrgid(status.st_gid)) != NULL)				
	fprintf(stderr,"\t%s", grp->gr_name);					/*id groupe*/
      
      fprintf(stderr,"\t%lu",status.st_size);					/*taille*/
      fflush(stdin);
      fprintf(stderr,"\t%-24.24s\t",ctime(&status.st_mtime));			/*date de modification*/
      fflush(stdin);
      
      if((ptdir=opendir(nom)) != NULL) { couleur("34"); fprintf(stderr,"%s\n",nom);couleur("0"); }
      else if((strstr(nom,".jpg"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".bmp"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".gif"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".wma"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".mp3"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".gz"))!=NULL)   {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".zip"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".tar"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,".taz"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      else if((strstr(nom,"."))==NULL)     {  couleur("32");  fprintf(stderr,"%s\n",nom); couleur("0"); }
      
      else  fprintf(stderr,"%s\n",nom);						/*affichage du nom de fichier ou du dossier*/
    }
}


void affiche_statusA (struct stat status,char * nom){				/*exécution de myls -a "myls -a"*/

  
  struct passwd *pwd;
  struct group  *grp;
  DIR * ptdir;
  
  										/*affichage du type de fichier ou dossier*/
  if(S_ISBLK(status.st_mode))							
    fprintf(stderr, "b");
  else if(S_ISCHR(status.st_mode))
    fprintf(stderr, "c");
  else if(S_ISDIR(status.st_mode))
    fprintf(stderr, "d");
  else if(S_ISFIFO(status.st_mode))
    fprintf(stderr, "p");
  else if(S_ISLNK(status.st_mode))
    fprintf(stderr, "l");
  else if(S_ISREG(status.st_mode))
    fprintf(stderr, "-");
  else if(S_ISSOCK(status.st_mode))
    fprintf(stderr, "s");
  
  fprintf(stderr, status.st_mode & S_IRUSR ? "r" : "-");			/*affichage des droits*/
  fprintf(stderr, status.st_mode & S_IWUSR ? "w" : "-");
  fprintf(stderr, status.st_mode & S_IXUSR ? "x" : "-");
  fprintf(stderr, status.st_mode & S_IRGRP ? "r" : "-");
  fprintf(stderr, status.st_mode & S_IWGRP ? "w" : "-");
  fprintf(stderr, status.st_mode & S_IXGRP ? "x" : "-");
  fprintf(stderr, status.st_mode & S_IROTH ? "r" : "-");
  fprintf(stderr, status.st_mode & S_IWOTH ? "w" : "-");
  fprintf(stderr, status.st_mode & S_IXOTH ? "x" : "-");
  
  fprintf(stderr,"\t%ld",status.st_nlink);					/*affichage du lien*/
  
  if ((pwd = getpwuid(status.st_uid)) != NULL)					
    fprintf(stderr,"\t%s", pwd->pw_name);					/*id utilisateur*/
  if ((grp = getgrgid(status.st_gid)) != NULL)					
    fprintf(stderr,"\t%s", grp->gr_name);					/*id groupe*/
  
  fprintf(stderr,"\t%lu",status.st_size);					/*taille*/
  fflush(stdin);
  fprintf(stderr,"\t%-24.24s\t",ctime(&status.st_mtime));			/*date de modification*/
  fflush(stdin);
  
  if((ptdir=opendir(nom)) != NULL) { couleur("34"); fprintf(stderr,"%s\n",nom);couleur("0"); }
  else if((strstr(nom,".jpg"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".bmp"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".gif"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".wma"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".mp3"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".gz"))!=NULL)   {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".zip"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".tar"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,".taz"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  else if((strstr(nom,"."))==NULL)     {  couleur("32");  fprintf(stderr,"%s\n",nom); couleur("0"); }
  
  else  fprintf(stderr,"%s\n",nom);						/*affichage du nom de fichier ou du dossier*/
}



void listdirR(char* dirname, int lvl){						/*exécution de myls -R "myls récursive"*/

  
  int i;
  DIR* d_fh;
  struct dirent* entry;
  char longest_name[4096];
  struct stat status;
  
  while( (d_fh = opendir(dirname)) == NULL) 
    {
      fprintf(stderr, "Couldn't open directory: %s\n", dirname);		/*erreur d'ouverture du dossier*/
      exit(-1);
    }
  										/*parcours du dossier*/
  while((entry=readdir(d_fh)) != NULL) 						
    {
      if(strncmp(entry->d_name, "..", 2) != 0 && strncmp(entry->d_name, ".", 1) != 0) 
	{
										/*teste si c'est un dossier*/
	  if (entry->d_type == DT_DIR)  					
	    {
	      for(i=0; i < 2*lvl; i++) ;
	      
	      strncpy(longest_name, dirname, 4095);				/*on fait la concaténation*/
	      strncat(longest_name, "/", 4095);
	      strncat(longest_name, entry->d_name, 4095);
	      couleur("34");
	      fprintf(stderr,"\n%s : \n",longest_name);
	      couleur("0");
	      
	      if(stat(longest_name,& status) >= 0) 
		affiche_statusR(status,longest_name,entry->d_name);		/*affichage récursif du dossier parcouru*/
	      
	      listdirR(longest_name, lvl++);					/*appel récursif*/
	    }
	  
	  else 
	    {
	      for(i=0; i < 2*lvl; i++) ;
	      
	      strncpy(longest_name, dirname, 4095);				/*on fait la concaténation*/
	      strncat(longest_name, "/", 4095);
	      strncat(longest_name, entry->d_name, 4095);
	      if(stat(longest_name,& status) >= 0) 
		affiche_statusR(status,longest_name,entry->d_name);
	    }
	}
    }         
  closedir(d_fh);	  
  return;
}


void affiche_statusR (struct stat status,char * nom,char * name){		/*affichage après un parcours récursif*/
  
  struct passwd *pwd;
  struct group  *grp;
  DIR * ptdir;
  if(stat(nom,& status) >= 0)
    {
      if(S_ISBLK(status.st_mode))
	fprintf(stderr, "b");
      else if(S_ISCHR(status.st_mode))
	fprintf(stderr, "c");
      else if(S_ISDIR(status.st_mode))
	fprintf(stderr, "d");
      else if(S_ISFIFO(status.st_mode))
	fprintf(stderr, "p");
      else if(S_ISLNK(status.st_mode))
	fprintf(stderr, "l");
      else if(S_ISREG(status.st_mode))
	fprintf(stderr, "-");
      else if(S_ISSOCK(status.st_mode))
	fprintf(stderr, "s");
      
      fprintf(stderr, status.st_mode & S_IRUSR ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWUSR ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXUSR ? "x" : "-");
      fprintf(stderr, status.st_mode & S_IRGRP ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWGRP ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXGRP ? "x" : "-");
      fprintf(stderr, status.st_mode & S_IROTH ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWOTH ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXOTH ? "x" : "-");
      
      fprintf(stderr,"\t%ld",status.st_nlink);
      
      if ((pwd = getpwuid(status.st_uid)) != NULL)
	fprintf(stderr,"\t%s", pwd->pw_name);
      if ((grp = getgrgid(status.st_gid)) != NULL)
	fprintf(stderr,"\t%s", grp->gr_name);
      
      fprintf(stderr,"\t%lu",status.st_size);
      fprintf(stderr,"\t%-24.24s\t",ctime(&status.st_mtime));
      fflush(stdin);
      
      if((ptdir=opendir(nom)) != NULL) { couleur("34"); fprintf(stderr,"%s\n",name);couleur("0"); }
      else if((strstr(name,".jpg"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".bmp"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".gif"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".wma"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".mp3"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".gz"))!=NULL)   {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".zip"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".tar"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".taz"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,"."))==NULL)     {  couleur("32");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else  fprintf(stderr,"%s\n",name);
      
    }
}


void listdirAR(char* dirname, int lvl){						/*exécution de myls -R -a "myls récursive affichant les fichiers cachés"*/

  
  int i;
  DIR* d_fh;
  struct dirent* entry;
  char longest_name[4096];
  struct stat status;
  
  while( (d_fh = opendir(dirname)) == NULL) 
    {
      fprintf(stderr, "Couldn't open directory: %s\n", dirname);
      exit(-1);
    }
  
  while((entry=readdir(d_fh)) != NULL) 
    {
    										/*Cas d'un fichier caché*/
      if((strcmp(entry->d_name, "..") == 0)  || (entry->d_name[0]=='.'
       && strcmp(entry->d_name,dirname)!=0)) 					
	{
	  strncpy(longest_name, dirname, 4095);
	  strncat(longest_name, "/", 4095);
	  strncat(longest_name, entry->d_name, 4095);
	  if(stat(longest_name,& status) >= 0) 
	    affiche_statusAR(status,longest_name,entry->d_name);
	}
      else
	{
										/*repertoire différent du courant ni du parent*/
	  if ((entry->d_type == DT_DIR) && (strncmp(entry->d_name, "..", 2) != 0
	   && strncmp(entry->d_name, ".", 1) != 0)) 				
	    {
	      for(i=0; i < 2*lvl; i++) ;
	      
	      strncpy(longest_name, dirname, 4095);
	      strncat(longest_name, "/", 4095);
	      strncat(longest_name, entry->d_name, 4095);
	      couleur("34");
	      fprintf(stderr,"\n%s : \n",longest_name);
	      couleur("0");
	      
	      if(stat(longest_name,& status) >= 0) 
		affiche_statusAR(status,longest_name,entry->d_name);		/*affichage récursif avec fichiers cachés*/
	      
	      listdirAR(longest_name, lvl++);					/*appel récursif*/
	    }
	  
	  else 
	    {
	      for(i=0; i < 2*lvl; i++) ;
	      
	      strncpy(longest_name, dirname, 4095);
	      strncat(longest_name, "/", 4095);
	      strncat(longest_name, entry->d_name, 4095);
	      if(stat(longest_name,& status) >= 0) 
		affiche_statusAR(status,longest_name,entry->d_name);
	    }
	}
    }         
  closedir(d_fh);	  
  return;
}


void affiche_statusAR (struct stat status,char * nom,char * name){		/*affichage récursif avec fichiers cachés*/
  
  
  struct passwd *pwd;
  struct group  *grp;
  DIR * ptdir;
  if(stat(nom,& status) >= 0)
    {
      
      if(S_ISBLK(status.st_mode))
	fprintf(stderr, "b");
      else if(S_ISCHR(status.st_mode))
	fprintf(stderr, "c");
      else if(S_ISDIR(status.st_mode))
	fprintf(stderr, "d");
      else if(S_ISFIFO(status.st_mode))
	fprintf(stderr, "p");
      else if(S_ISLNK(status.st_mode))
	fprintf(stderr, "l");
      else if(S_ISREG(status.st_mode))
	fprintf(stderr, "-");
      else if(S_ISSOCK(status.st_mode))
	fprintf(stderr, "s");
      
      fprintf(stderr, status.st_mode & S_IRUSR ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWUSR ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXUSR ? "x" : "-");
      fprintf(stderr, status.st_mode & S_IRGRP ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWGRP ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXGRP ? "x" : "-");
      fprintf(stderr, status.st_mode & S_IROTH ? "r" : "-");
      fprintf(stderr, status.st_mode & S_IWOTH ? "w" : "-");
      fprintf(stderr, status.st_mode & S_IXOTH ? "x" : "-");
      
      fprintf(stderr,"\t%ld",status.st_nlink);
      
      if ((pwd = getpwuid(status.st_uid)) != NULL)
	fprintf(stderr,"\t%s", pwd->pw_name);
      if ((grp = getgrgid(status.st_gid)) != NULL)
	fprintf(stderr,"\t%s", grp->gr_name);
      
      fprintf(stderr,"\t%lu",status.st_size);
      fprintf(stderr,"\t%-24.24s\t",ctime(&status.st_mtime));
      fflush(stdin);
      
      if((ptdir=opendir(nom)) != NULL) { couleur("34"); fprintf(stderr,"%s\n",name);couleur("0"); }
      else if((strstr(name,".jpg"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".bmp"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".gif"))!=NULL)  {  couleur("35");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".wma"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".mp3"))!=NULL)  {  couleur("36");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".gz"))!=NULL)   {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".zip"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".tar"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,".taz"))!=NULL)  {  couleur("31");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else if((strstr(name,"."))==NULL)     {  couleur("32");  fprintf(stderr,"%s\n",name); couleur("0"); }
      else  fprintf(stderr,"%s\n",name);
      
     
    }
}

static int nombreOptions(char** option){					/*retourne le nombre d'options*/
int i;
while(option[i]) i++;

return i;

}


void  myls(){									/*gestion du myls*/

int i;
DIR * ptdir;
struct stat status;
struct dirent * entree;

opt = (char**)recupererCommande(ligneCommande, " ");

int argc = (int)nombreOptions(opt);

 if(argc>=3 && (((strstr(opt[1],"-a"))==0 && (strcmp(opt[2],"-R"))==0) || ((strcmp(opt[1],"-R"))==0 && (strcmp(opt[2],"-a"))==0)) )
    {
      if (argc == 3)   listdirAR(".", 0);
      else	for(i=3;i<argc;i++) { listdirAR(opt[i], 0); printf("\n\n");  }
      
      printf("\n");
    }
  
  else if(argc>=2 && ((strcmp(opt[1],"-aR"))==0 || (strcmp(opt[1],"-Ra"))==0 ))
    { 
      if (argc == 2)   listdirAR(".", 0);
      else	for(i=2;i<argc;i++) { listdirAR(opt[i], 0); printf("\n\n");  }
      
      printf("\n");
    }
  
  else if(argc>=2 && ((strcmp(opt[1],"-R"))==0))
    {
      if (argc == 2)   listdirR(".", 0);
      else	for(i=2;i<argc;i++) { listdirR(opt[i], 0); printf("\n\n");  }
      
      printf("\n");
    }
   else if(argc>=2 && ((strcmp(opt[1],"-a"))==0))
    {
      if(argc==2)
	{ 
	  if ((ptdir = opendir(".")) != NULL)
	    {
	      while ((entree = readdir (ptdir)) != NULL)
		{
		  if(stat(entree->d_name,& status) >= 0)
		    affiche_statusA(status,entree->d_name);
		}
	    }
	  else perror(" ");
	}
      else
	{ 
	  for(i=2;i<argc; i++)
	    {
	      if ((ptdir = opendir(opt[i])) != NULL)
		{
		  fprintf(stdout,"%s : \n",opt[i]);
		  chdir(opt[i]);
		  while ((entree = readdir (ptdir)) != NULL)
		    {
		      if(stat(entree->d_name,& status) >= 0)
			affiche_statusA(status,entree->d_name);
		      
		    }
		  chdir("..");
		}
	      else { fprintf(stderr,"ls: impossible d'accéder à %s",opt[i]); perror(" "); }	
	    }
	}
      closedir(ptdir);
    }
  else
    {
      if(argc==1)
	{ 
	  if ((ptdir = opendir(".")) != NULL)
	    {
	      while ((entree = readdir (ptdir)) != NULL)
		{
		  if(stat(entree->d_name,& status) >= 0)
		    affiche_statusL(status,entree->d_name);
		}
	    }
	  else perror(" ");
	}
      else
	{ 
	  for(i=1;i<argc; i++)
	    {
	      if ((ptdir = opendir(opt[i])) != NULL)
		{
		  fprintf(stdout,"%s : \n",opt[i]);
		  chdir(opt[i]);
		  while ((entree = readdir (ptdir)) != NULL)
		    {
		      if(stat(entree->d_name,& status) >= 0)
			affiche_statusL(status,entree->d_name);
		      
		    }
		  chdir("..");
		}
	      else { fprintf(stderr,"ls: impossible d'accéder à %s",opt[i]); perror(" "); }
	    }
	}
      closedir(ptdir);
    }
  
}

/**
/* SEM_UNDO: Employée lors d'une opération permet au processus de s'assurer qu'en
/* cas de terminaison impromptue alors qu'il bloque un sémaphore le noyau en restituera
/* l'état initial.
 **/

void _V(int identifiant){

struct sembuf sembuf;
sembuf.sem_num = 0;
sembuf.sem_op  = 1;
sembuf.sem_flg = SEM_UNDO;
CHECK(semop(identifiant,&sembuf,1),"Echec V() - semop()");
}

void _P(int identifiant){

struct sembuf sembuf;
sembuf.sem_num = 0;
sembuf.sem_op  = -1;
sembuf.sem_flg = SEM_UNDO;
CHECK(semop(identifiant,&sembuf,1),"Echec P() - semop()");

}

int newSemaphore(int init){
srand(time(NULL));

int id =  rand()%('z' - 'a') + 'a';

key_t key;

int semaphore;
 
 CHECK((key = ftok("/bin/ls",id++)),"Erreure de création de clé - ftok()");
 
 if(((semaphore = semget(key,1,IPC_CREAT|IPC_EXCL|0600)) != -1) || ((semaphore = semget(key,1,0600)) != -1))
 {
    if(semctl(semaphore,0,SETVAL,init) == -1)
    {
        perror("Erreur initialisatioin de sémaphore - semctl()");
        exit(EXIT_FAILURE);
    }
 }
 else
 {
    perror("Erreur de création de sémaphore - semget()");
    exit(EXIT_FAILURE);
 }
   
 return semaphore;
 
}

void freeMemoire(void* valeur,int mem){
 
 CHECK(shmdt(valeur),"Echec Détachement - shmdt()");

 CHECK(shmctl(mem,IPC_RMID,NULL),"Erreur de libération de la mémoire freeMemoire() - shmctl()");    
 
}


void freeSemaphore(int sem){

    CHECK(shmctl(sem,IPC_RMID,NULL),"Erreur de libération de la sémaphore freeSemaphore() - shmctl()");
}


void * newMemoire(size_t size,int *shm){

srand(time(NULL));

int id =  rand()%('z' - 'a') + 'a';

key_t key;

void *p;

CHECK((key = ftok("/bin/cat",id)),"Erreure de création de clé - ftok()");

if( ((*shm = shmget(key,size,IPC_CREAT|IPC_EXCL|0600)) == -1) && ((*shm = shmget(key,size,0600)) == -1))
{                               
   perror("Erreure de création de  la mémoire - semget()");
   exit(EXIT_FAILURE);
}

if((p = (void *)shmat(*shm,NULL,0)) == (void*)-1)
{
   perror("Echec Attachement - shmat()");
   exit(EXIT_FAILURE);
}

return p;

}       

Variable* initVariable(int size){

Variable *var  = (Variable*)malloc(sizeof(Variable)*size);
var->Element   = (Var*)malloc(sizeof(Var)*size);
var->N         = 0;
return var;

}

void  detruireTabVar(Variable* v){

free(v->Element);
free(v);
}

void _set_(char* ligneCommande){
Var var;

int sem,shm;

sem = newSemaphore(1);

V = (Variable *)newMemoire(TAILLE_MEMOIRE,&shm);

_P(sem);

char** commande = recupererCommande(ligneCommande,"=");

strcpy(var.nomVariable,*commande);

strcpy(var.valeurVariable,*(commande+1));

var.typeVariable = 'L';

(V+NBV)->Element = &var;

NBV++;

free(commande);

_V(sem);

}

void _set(){
int i = 0;
int sem,shm;
sem = newSemaphore(1);
V = (Variable *)newMemoire(TAILLE_MEMOIRE,&shm);

    while(i < NBV)
    {
           if(V[i].Element->typeVariable = 'L')
           {
              printf("%s = %s\n",colorer(YELLOW,V[i].Element->nomVariable),colorer(BLUE,V[i].Element->valeurVariable));
           }
           i++;
    }

}


void _setenv_(char* ligneCommande){

char** commande = recupererCommande(ligneCommande,"=");

Var var;

strcpy(var.nomVariable,*commande);

strcpy(var.valeurVariable,*(commande+1));

var.typeVariable = 'E';

V->Element[V->N++] = var;

free(commande);

}

void _setenv(){
int i = 0;

  while(i < V->N)
  {
      if(V->Element[i].typeVariable = 'E')
            printf("%s = %s\n",colorer(YELLOW,V->Element[i].nomVariable),colorer(BLUE,V->Element[i].valeurVariable));
       i++;
  }

}



