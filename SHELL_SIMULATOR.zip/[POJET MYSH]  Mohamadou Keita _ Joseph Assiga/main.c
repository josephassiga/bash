#include "unistd.h" 
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "glob.h"
#include "sys/wait.h"
#include "Fonction.h"

/*pour gérer la fonction readline et l'historique :
 *intaller d'abord le paquet suivant sudo apt-get install libreadline-dev
 *pour la compilatioin: gcc -Wall shell.c -shell -lreadline -g
 */
#include "readline/readline.h"
#include "readline/history.h"

char* help[] = {"\t\t------------------------------------------------------------------------------------------\n"
                "\t\t--               Projet MiniShell : Système d'Exloitation Centralisé                    --\n"
                "\t\t------------------------------------------------------------------------------------------\n"
                "\t\t-- quit - exit - q :          Sortir du shell.                                          --\n"
                "\t\t-- cd dossier      :          Changer le repertoire courant.                            --\n"
                "\t\t-- help - h ?      :          Afficher l'aide.                                          --\n"
                "\t\t-- myps            :          équivalent à ps aux pour lister les processus du système. --\n"
                "\t\t-- myls            :          pour lister les contenus des repertoires.                 --\n"
                "\t\t-- myfg            :          envois un processus en foreground (avant-plan).           --\n"
                "\t\t--                            par défaut il prend le processus le plus ancien en        --\n"    
                "\t\t--                            backGround et le mets en avant-plan. Il peut aussi        --\n"
                "\t\t--                            recevoir le pid d'un processus particulier, on utilise    --\n"
                "\t\t--                            à cet effet _myfg(pid).                                   --\n"
                "\t\t-- myfg            :          envois un processus en background (arrière-plan).         --\n"
                "\t\t--                            _mybg(pid) pour un processus particulier.                 --\n"   
                "\t\t--                                                                                      --\n"
                "\t\t-- sequencement    :          isSequenceAlternative(char*):teste si on a ; ou || ou &&  --\n"
                "\t\t--                            return 1 if true and 0 if false.                          --\n"
                "\t\t--                            sequenceAlternative(void): taritement des instructions.   --\n"
                "\t\t-- pipe            :          isPipe(char*): test si on a |                             --\n"
                "\t\t--                            return 1 if true and 0 if false.                          --\n"
                "\t\t--                            execPipe(num_pipe): traitement recursif des instructions. --\n"
                "\t\t-- redirection     :          isRedirection(char*): teste si on a >,>>,2>,2>>,>k,>>,<.  --\n"
                "\t\t--                            return 1 if true and 0 if false.                          --\n"
                "\t\t--                            execRedirection(): taritement des instructioins.          --\n"
                "\t\t-- wildcar         :          gestion de méta-caractères.                               --\n"
                "\t\t-- history - y     :          Affiche l'historique des commande.                        --\n"
                "\t\t-- myjobs          :          Affiche les processus lancés en arrière plan              --\n"
                "\t\t--                                                                                      --\n"
                "\t\t-------------------------------      AUTHOR        ---------------------------------------\n"
                "\t\t-- Mohamadou Keita                 Bertrand Mazure               Joseph Assiga          --\n"
                "\t\t------------------------------------------------------------------------------------------\n"
             };

int main(){
    
     P = NULL;
     int i;
     int erreur;
     pid_t pid;
     glob_t chemins;
     char*  ret = NULL;

     /**
      * Initialisation de la table des processus: par défaut 
      * je crèe une table de 100 processus.
      **/
     P = initTable(100);

     
     /* Initialisation du tableau de variable.*/
     V = initVariable(100);
     
     
     using_history();
     
     if(signal(SIGINT,handler_ctrc) == SIG_ERR)
     {
       perror("Erreur signal - SIGINT: ");
       exit(-1);
     }

      if(signal(SIGCHLD,gestionFils) == SIG_ERR)
      {
         perror("Erreure signal - SIGCHLD: ");
         exit(-1);
      }
     
     if(signal(SIGTSTP,gestion_ctrz) == SIG_ERR)
     {
       perror("Erreur signal - SIGCHLD: ");
       exit(-1);
     }
     
     CHECK(atexit(sortieShell),"Impossible de exécuter sortieShell() -atexit()");
                 
     while(TRUE)
     {	
        /* Je vide l'entrée standard. */
        fflush(stdin);
        
        /*Initialisation des variables*/
        init();
        
        /*Recupère la commande entrée.*/
        ligneCommande = readline((const char*)colorer(BLUE,(char*)prompt()));
        
        if(!strlen(ligneCommande)) continue;
        
        /* j'ajoute ma commande dans mon historique. */
        add_history(ligneCommande);
        
        if(!strncmp(ligneCommande,"exit",4) || !strncmp(ligneCommande,"quit",4) || !strncmp(ligneCommande,"q",1)) 
        {             
             exit(EXIT_SUCCESS);
        }
        else if (!(strncmp(ligneCommande,"cd", 2))) 
        { 
                opt = recupererCommande(ligneCommande," ");
                if(*(opt + 1) == NULL) continue;
                if (strncmp(opt[1] , "~" ,1) == 0)
                {
                    dir = getenv("HOME");
                }
                else
                {
                    dir = opt[1];
                }
                
                if (chdir(dir) == 0) 
                {
                    dir = getcwd(NULL, 0);
                } 
                else
                {
                    fprintf(stderr,"%s directory change failed\n",opt[1]);
                }
                
        }
        else if( (strchr(ligneCommande,'*')) && (!strchr(ligneCommande,';')) && (!strstr(ligneCommande,"&&")) && (!strstr  (ligneCommande,"||")) && (!strchr(ligneCommande,'|')) && (!strchr(ligneCommande,'>')))
        {         
                      CHECK((pid = fork()),"Erreure Création de Processus: ");

                      chemins = (glob_t)gestionWildCar(ligneCommande);
                      
                      opt = recupererCommande(ligneCommande, " ");                      
                      if(pid == 0)
                      {
	        	  execvp(opt[0], &chemins.gl_pathv[0]);
                      }
                      else
                      {
                         waitChild(pid,status);
                         globfree(& chemins);
                         free(opt);
                         free(ligneCommande);
                      }
		    
        }
        else if(!strncmp(ligneCommande,"set",3))
        {
           char*str;
           if((str = strtok(ligneCommande,"set")))
           {
              _set_(trim(str));                
           }
           else
           {
              _set();
           }
        }
        else if(!strncmp(ligneCommande,"setenv",6))
        {
           char*str;
           if((str = strtok(ligneCommande,"setenv")))
           {
              _setenv_(trim(str));                
           }
           else
           {
              _setenv();
           }
        
        
        }
        else if( (!strncmp(ligneCommande,"history", 7)) || (!strncmp(ligneCommande,"y", 1)))
        { 
                HIST_ENTRY **histlist;
                int i;
                histlist =  history_list();
                if (histlist)
                {
                    for (i = 0; histlist[i]; i++) printf ("%d: %s\n", i , histlist[i]->line);
                }
        }
        else if(!strncmp(ligneCommande,"myjobs",6))
        {
                 myjobs(P);
        }
        else if((!strncmp(ligneCommande,"help",4)) || (!strncmp(ligneCommande,"?",1) || (!strncmp(ligneCommande,"h",1))))
        {
                printf("%s\n",colorer(YELLOW,(char*)help[0]));
                free(ligneCommande);
        }
        else if(!strncmp(ligneCommande,"myps",4))
        {
                myps();
        }
        else if(!strncmp(ligneCommande,"myls",4))
        {
                myls();
        }
        else if(!strncmp(ligneCommande,"mybg",4))
        {
                 opt = recupererCommande(ligneCommande, " ");
                 if(!strlen(opt[1]))
                 {
                    mybg();
                 }
                 else
                 {
                   _mybg(opt[1]);
                 }
        }
        else if(!strncmp(ligneCommande,"myfg",4))
        {        opt = recupererCommande(ligneCommande, " ");
                 if(!strlen(opt[1]))
                 {
                    myfg();
                 }
                 else
                 {
                   _myfg(opt[1]);
                 }
        }
        else
        {
                if((ret = strchr(ligneCommande,'&')) && (*(ret+1)!='&'))
                {
                    arrierePlan(ligneCommande);
                }
                else if(isRedirection(ligneCommande))
                {
                   execRedirection();
                }
                else if(isPipe(ligneCommande))
                {  
                    execPipe(0);                  
                }
                else if(isSequenceAlternative(ligneCommande))
                {
                   sequenceAlternative();
                }
                else 
                {      
                        CHECK((pid = fork()),"Erreure Création de Processus: ");
                        opt = recupererCommande(ligneCommande, " ");
                        if(pid == 0)
                        { 
                                   execvp((const char*)opt[0],opt);
                                   perror("Erreur de la fonction execvp");
                                   exit(ERREUR_EXEC);
                        }
                        else
                        {
                                 waitChild(pid,status);
                                 free(opt);
                                 free(ligneCommande);
                        }
                }
        }
    
        
        
  }
     
     return EXIT_SUCCESS;

}



